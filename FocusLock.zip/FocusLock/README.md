# FOCUS LOCK (com.daksh.focuslock)

Schedule-based app blocker for Android. Kotlin, Jetpack Compose (Material 3), Room, DataStore, MVVM + repositories.

> **Status: written but NOT compiled or tested by the author.** The first CI build may show compile errors; paste the log and fix. Nothing here has been verified on a real device.

## Build (no Android Studio, GitHub only)
1. Upload `FocusLock.zip` to the repo root (do not extract).
2. Add `.github/workflows/build.yml` (provided separately).
3. Actions tab -> "Build FOCUS LOCK APK" -> download artifact `FocusLock-debug-apk`.

Local: `gradle assembleDebug` (Gradle 8.7, JDK 17) -> `app/build/outputs/apk/debug/app-debug.apk`. Unit tests: `gradle testDebugUnitTest`. Device tests: `gradle connectedDebugAndroidTest`.

## Setup on phone
Open app -> Permissions -> Enable -> turn on FOCUS LOCK in Accessibility. If greyed out (sideloaded APK): App info -> menu -> "Allow restricted settings". Set battery to Unrestricted.

## Architecture
- `domain/` pure Kotlin: `ScheduleEvaluator` (start-inclusive, end-exclusive, overnight, DST), `BlockingEngine`, `StrictPolicy`, `ContentBlocker` + YouTube/Instagram detectors, `StatsCalculator`.
- `data/` Room (`schedules`, `sessions`, `block_events`), DataStore prefs, repositories, `AppsRepository`.
- `accessibility/` the AccessibilityService, `AlarmScheduler` (one inexact alarm for the next boundary).
- `receiver/` boot, time-set, timezone-change, package-replaced -> recalculates state.
- `ui/` Compose screens, navigation, `BlockedActivity`.

## Permissions
Only `RECEIVE_BOOT_COMPLETED`. App list uses a `<queries>` LAUNCHER intent (no `QUERY_ALL_PACKAGES`); Play Store may still review the Accessibility use. No exact alarms, no notifications, no overlay, no usage access, no internet.

## Honest limitations
- Not tamper-proof: user can disable the service, force-stop or uninstall. Strict mode only locks in-app editing.
- OEM battery managers may stop the service.
- Shorts/Reels detection is experimental (view-id + label hints) and unverified on real app versions.
- Simplifications: apps stored as a comma list per schedule; preferences are in DataStore (no Room prefs entity); UI strings are inline English (not yet extracted for Hindi); ViewModel and UI instrumentation tests not written.
- Session durations are estimates (counted while the device was observed running).

## Release signing
Create a keystore locally, keep it out of git, add a `signingConfigs` block reading passwords from environment variables, then `gradle assembleRelease`.
