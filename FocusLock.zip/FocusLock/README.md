# FOCUS LOCK 2.0.0 (com.daksh.focuslock)

Schedule-based app blocker for Android. Kotlin, Jetpack Compose (Material 3), Room, DataStore, MVVM + repositories.

> **Status: written but NOT compiled or tested by the author.** The first CI build may show compile errors; paste the log and fix. Nothing here has been verified on a real device.

## V2 changes (all UNVERIFIED: not compiled or run by the author)
- Service: whole event handler wrapped in try/catch; background coroutines have an exception handler; an uncaught-exception hook stores the last crash; health (connected, last event, last failure, disconnect count) is shown on the dashboard and in "Service and permissions". Probable V1 causes (no logcat was available, so NOT confirmed): an uncaught exception in a background coroutine or the event handler crashing the process, and OEM battery management. Android can't be told to restart the service; the UI says so.
- Shorts/Reels: detector now also treats a selected "Shorts"/"Reels" tab as a strong signal; label-only never blocks; nodes released; reason codes + optional in-memory diagnostic log (Settings -> Shorts/Reels). Real-app behaviour is unverified.
- Editor: start/end cards, dial or typed time, system 12/24h, 25m/45m/1h/2h presets, overlap warning, live summary, duplicate/delete.
- Dashboard: focus ring, recent events, service health. Onboarding removed. Database unchanged (still v1, no migration needed).
- Performance: dashboard recompute is event-driven (next schedule boundary, plus once a minute only while a session is active); content-change events from other apps return immediately; app list cached.
- Not done: "start session now" quick action, Compose/benchmark profiling, lint run, emulator/device tests.

## Build (no Android Studio, GitHub only)
1. Upload `FocusLock.zip` to the repo root (do not extract).
2. Add `.github/workflows/build.yml` (provided separately).
3. Actions tab -> "Build FOCUS LOCK APK" -> download artifact `FocusLock-debug-apk`.

Local: `gradle assembleDebug` (Gradle 8.7, JDK 17) -> `app/build/outputs/apk/debug/app-debug.apk`. Unit tests: `gradle testDebugUnitTest`. Device tests: `gradle connectedDebugAndroidTest`.

## Setup on phone
Open app -> Permissions -> Enable -> turn on FOCUS LOCK in Accessibility. If greyed out (sideloaded APK): App info -> menu -> "Allow restricted settings". Set battery to Unrestricted.

## Architecture
- `domain/` pure Kotlin: `ScheduleEvaluator` (start-inclusive, end-exclusive, overnight, DST), `BlockingEngine`, `StrictPolicy`, `ContentBlocker` + YouTube/Instagram detectors, `StatsCalculator`.
- `data/` Room (`schedules`, `sessions`, `block_events`), DataStore prefs, repositories, `AppsRepository`.
- `accessibility/` the AccessibilityService, `AlarmScheduler` (one inexact alarm for the next boundary).
- `receiver/` boot, time-set, timezone-change, package-replaced -> recalculates state.
- `ui/` Compose screens, navigation, `BlockedActivity`.

## Permissions
Only `RECEIVE_BOOT_COMPLETED`. App list uses a `<queries>` LAUNCHER intent (no `QUERY_ALL_PACKAGES`); Play Store may still review the Accessibility use. No exact alarms, no notifications, no overlay, no usage access, no internet.

## Honest limitations
- Not tamper-proof: user can disable the service, force-stop or uninstall. Strict mode only locks in-app editing.
- OEM battery managers may stop the service.
- Shorts/Reels detection is experimental (view-id + label hints) and unverified on real app versions.
- Simplifications: apps stored as a comma list per schedule; preferences are in DataStore (no Room prefs entity); UI strings are inline English (not yet extracted for Hindi); ViewModel and UI instrumentation tests not written.
- Session durations are estimates (counted while the device was observed running).

## Release signing
Create a keystore locally, keep it out of git, add a `signingConfigs` block reading passwords from environment variables, then `gradle assembleRelease`.
