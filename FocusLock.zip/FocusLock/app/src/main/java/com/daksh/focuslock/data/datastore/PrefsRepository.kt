package com.daksh.focuslock.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, DARK, LIGHT }

data class Prefs(
    val theme: ThemeMode = ThemeMode.DARK,
    val onboardingDone: Boolean = false,
    val blockShorts: Boolean = false,
    val blockReels: Boolean = false,
    val fallbackWholeApp: Boolean = false,
    val emergencyOverride: Boolean = false,
    val overrideUntil: Long = 0L,
    val motivation: Boolean = true
)

private val Context.store: DataStore<Preferences> by preferencesDataStore(name = "settings")

class PrefsRepository(private val ctx: Context) {
    private object K {
        val THEME = stringPreferencesKey("theme")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val SHORTS = booleanPreferencesKey("block_shorts")
        val REELS = booleanPreferencesKey("block_reels")
        val FALLBACK = booleanPreferencesKey("fallback_whole_app")
        val OVERRIDE = booleanPreferencesKey("emergency_override")
        val OVERRIDE_UNTIL = longPreferencesKey("override_until")
        val MOTIVATION = booleanPreferencesKey("motivation")
    }

    val flow: Flow<Prefs> = ctx.store.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            Prefs(
                theme = runCatching { ThemeMode.valueOf(p[K.THEME] ?: "DARK") }.getOrDefault(ThemeMode.DARK),
                onboardingDone = p[K.ONBOARDING] ?: false,
                blockShorts = p[K.SHORTS] ?: false,
                blockReels = p[K.REELS] ?: false,
                fallbackWholeApp = p[K.FALLBACK] ?: false,
                emergencyOverride = p[K.OVERRIDE] ?: false,
                overrideUntil = p[K.OVERRIDE_UNTIL] ?: 0L,
                motivation = p[K.MOTIVATION] ?: true
            )
        }

    suspend fun setTheme(m: ThemeMode) { ctx.store.edit { it[K.THEME] = m.name } }
    suspend fun setOnboardingDone() { ctx.store.edit { it[K.ONBOARDING] = true } }
    suspend fun setBlockShorts(v: Boolean) { ctx.store.edit { it[K.SHORTS] = v } }
    suspend fun setBlockReels(v: Boolean) { ctx.store.edit { it[K.REELS] = v } }
    suspend fun setFallback(v: Boolean) { ctx.store.edit { it[K.FALLBACK] = v } }
    suspend fun setEmergencyOverride(v: Boolean) { ctx.store.edit { it[K.OVERRIDE] = v } }
    suspend fun setOverrideUntil(v: Long) { ctx.store.edit { it[K.OVERRIDE_UNTIL] = v } }
    suspend fun setMotivation(v: Boolean) { ctx.store.edit { it[K.MOTIVATION] = v } }
}
