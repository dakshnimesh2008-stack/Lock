package com.daksh.focuslock.domain.blocking

import com.daksh.focuslock.domain.model.ActiveRule
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import java.time.Instant
import java.time.ZoneId

/** UI-independent blocking decisions. Holds the latest schedules; all methods take the instant to evaluate. */
class BlockingEngine(private val ownPackage: String = "com.daksh.focuslock") {

    @Volatile
    private var schedules: List<FocusSchedule> = emptyList()

    fun updateSchedules(list: List<FocusSchedule>) {
        schedules = list
    }

    fun refreshActiveSchedules(instant: Instant, zone: ZoneId = ZoneId.systemDefault()): List<ActiveRule> =
        schedules.mapNotNull { s ->
            ScheduleEvaluator.activeWindow(s, instant, zone)?.let { ActiveRule(s, it) }
        }

    fun getActiveRules(instant: Instant, zone: ZoneId = ZoneId.systemDefault()): List<ActiveRule> =
        refreshActiveSchedules(instant, zone)

    fun isPackageBlocked(packageName: String, instant: Instant, zone: ZoneId = ZoneId.systemDefault()): Boolean =
        getActiveRules(instant, zone).any { packageName in it.schedule.packages }

    fun shouldBlockLaunch(packageName: String, instant: Instant, zone: ZoneId = ZoneId.systemDefault()): Boolean =
        packageName != ownPackage &&
            packageName !in ProtectedPackages.fixed &&
            isPackageBlocked(packageName, instant, zone)
}
