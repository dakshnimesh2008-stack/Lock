package com.daksh.focuslock.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [ScheduleEntity::class, SessionEntity::class, BlockEventEntity::class],
    version = 1,
    exportSchema = true
)
abstract class FocusDatabase : RoomDatabase() {
    abstract fun scheduleDao(): ScheduleDao
    abstract fun sessionDao(): SessionDao
    abstract fun blockEventDao(): BlockEventDao

    companion object {
        fun build(ctx: Context): FocusDatabase =
            Room.databaseBuilder(ctx.applicationContext, FocusDatabase::class.java, "focuslock.db")
                .addMigrations(*Migrations.ALL)
                .build() // No destructive fallback by design: add a Migration when bumping the version.
    }
}

object Migrations {
    val ALL: Array<Migration> = arrayOf<Migration>()
}
