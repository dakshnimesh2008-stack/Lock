package com.daksh.focuslock.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.daksh.focuslock.data.datastore.ThemeMode

val Violet = Color(0xFF8B5CF6)

private val DarkScheme = darkColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2E1F5E),
    onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = Color(0xFFA78BFA),
    background = Color.Black,
    onBackground = Color.White,
    surface = Color(0xFF07070B),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF14141C),
    onSurfaceVariant = Color(0xFFA0A0B4),
    outline = Color(0xFF2B2B3B),
    error = Color(0xFFFF6B6B)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6D28D9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE9DDFF),
    onPrimaryContainer = Color(0xFF260A63),
    secondary = Color(0xFF7C5CD6),
    background = Color(0xFFFBF9FF),
    onBackground = Color(0xFF121018),
    surface = Color.White,
    onSurface = Color(0xFF121018),
    surfaceVariant = Color(0xFFF0EBFA),
    onSurfaceVariant = Color(0xFF5E5A70),
    outline = Color(0xFFD5CEE6),
    error = Color(0xFFB3261E)
)

@Composable
fun FocusLockTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = Typography(), content = content)
}
