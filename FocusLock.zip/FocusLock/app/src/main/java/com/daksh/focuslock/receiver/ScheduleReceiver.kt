package com.daksh.focuslock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.daksh.focuslock.graph
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.TimeZone

/** Handles schedule-boundary alarms, reboot, manual time change, time-zone change and app update. */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_TIMEZONE_CHANGED) TimeZone.setDefault(null)
        val pending = goAsync()
        val g = context.applicationContext.graph
        g.appScope.launch(Dispatchers.IO) {
            try {
                g.runMaintenance()
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_BOUNDARY = "com.daksh.focuslock.ACTION_BOUNDARY"
    }
}
