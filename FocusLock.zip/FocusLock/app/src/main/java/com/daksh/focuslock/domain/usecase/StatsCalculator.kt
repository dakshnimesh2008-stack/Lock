package com.daksh.focuslock.domain.usecase

import com.daksh.focuslock.domain.model.BlockRecord
import com.daksh.focuslock.domain.model.SessionRecord
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class Stats(
    val todayFocusMs: Long = 0,
    val week: List<Pair<LocalDate, Long>> = emptyList(),
    val completedSessions: Int = 0,
    val completedToday: Int = 0,
    val totalSessions: Int = 0,
    val attempts: Int = 0,
    val confirmed: Int = 0,
    val attemptsToday: Int = 0,
    val topApps: List<Pair<String, Int>> = emptyList()
)

object StatsCalculator {

    /** Splits [startMs, endMs) at local midnights. */
    fun splitByDay(startMs: Long, endMs: Long, zone: ZoneId): Map<LocalDate, Long> {
        val out = linkedMapOf<LocalDate, Long>()
        if (endMs <= startMs) return out
        var cur = Instant.ofEpochMilli(startMs)
        val end = Instant.ofEpochMilli(endMs)
        while (cur.isBefore(end)) {
            val date = cur.atZone(zone).toLocalDate()
            val nextMidnight = date.plusDays(1).atStartOfDay(zone).toInstant()
            val segEnd = if (nextMidnight.isBefore(end)) nextMidnight else end
            out[date] = (out[date] ?: 0L) + (segEnd.toEpochMilli() - cur.toEpochMilli())
            cur = segEnd
        }
        return out
    }

    fun compute(sessions: List<SessionRecord>, events: List<BlockRecord>, nowMs: Long, zone: ZoneId): Stats {
        val perDay = HashMap<LocalDate, Long>()
        for (s in sessions) {
            // Running session: count up to now. Finished: count up to the last time we saw the device alive.
            val end = if (nowMs < s.windowEnd) nowMs.coerceAtLeast(s.windowStart) else minOf(s.lastSeenAt, s.windowEnd)
            splitByDay(s.windowStart, end, zone).forEach { (d, ms) -> perDay[d] = (perDay[d] ?: 0L) + ms }
        }
        val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        val week = (6 downTo 0).map { off -> today.minusDays(off.toLong()).let { it to (perDay[it] ?: 0L) } }
        val completed = sessions.filter { it.completed }
        val completedToday = completed.count {
            Instant.ofEpochMilli(it.windowEnd).atZone(zone).toLocalDate() == today
        }
        val blocks = events.filter { it.type != "OVERRIDE" }
        val attemptsToday = blocks.count {
            Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() == today
        }
        val top = blocks.groupingBy { it.packageName }.eachCount().entries
            .sortedByDescending { it.value }.take(5).map { it.key to it.value }
        return Stats(
            todayFocusMs = perDay[today] ?: 0L,
            week = week,
            completedSessions = completed.size,
            completedToday = completedToday,
            totalSessions = sessions.size,
            attempts = blocks.size,
            confirmed = blocks.count { it.confirmed },
            attemptsToday = attemptsToday,
            topApps = top
        )
    }
}
