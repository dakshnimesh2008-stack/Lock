@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.session

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.dashboard.HomeViewModel
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.ui.util.rememberNowMs
import com.daksh.focuslock.util.formatClock
import com.daksh.focuslock.util.formatDuration
import com.daksh.focuslock.util.formatMinute

@Composable
fun SessionScreen(graph: AppGraph, onBack: () -> Unit) {
    val vm = graphViewModel(graph) { HomeViewModel(it) }
    val st by vm.state.collectAsStateWithLifecycle()
    val now by rememberNowMs()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Active focus session") }
        if (st.rules.isEmpty()) {
            item {
                FLCard {
                    Text("No session is active", style = MaterialTheme.typography.titleMedium)
                    Muted("Blocking only runs during your enabled schedules.")
                }
            }
        }
        st.rules.forEach { r ->
            item {
                FLCard {
                    Text(r.schedule.name, style = MaterialTheme.typography.titleLarge)
                    Text(
                        formatDuration(r.window.end.toEpochMilli() - now),
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Muted(
                        "Schedule ${formatMinute(r.schedule.startMinute)}–${formatMinute(r.schedule.endMinute)}, " +
                            "ends ${formatClock(r.window.end)}. ${r.schedule.packages.size} apps blocked."
                    )
                    if (r.schedule.strict) {
                        Text("Strict mode", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                        Muted("Why you can't change this schedule: you turned on Strict mode for it, and it is running until the time above.")
                    }
                }
            }
        }
        item {
            FLCard {
                Text("What Strict mode really does", style = MaterialTheme.typography.titleMedium)
                Muted(
                    "It stops editing, disabling and deleting the running schedule inside this app. " +
                        "It is NOT tamper-proof: you can still turn off the accessibility service, force-stop or " +
                        "uninstall the app in Android settings. Phone calls, emergency calling, the power button and " +
                        "Android settings are never blocked."
                )
            }
        }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
}
