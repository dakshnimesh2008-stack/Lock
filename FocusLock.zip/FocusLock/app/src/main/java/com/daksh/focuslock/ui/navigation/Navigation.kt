package com.daksh.focuslock.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.datastore.Prefs
import com.daksh.focuslock.ui.dashboard.DashboardScreen
import com.daksh.focuslock.ui.onboarding.OnboardingScreen
import com.daksh.focuslock.ui.schedules.ScheduleEditScreen
import com.daksh.focuslock.ui.schedules.SchedulesScreen
import com.daksh.focuslock.ui.session.SessionScreen
import com.daksh.focuslock.ui.settings.AboutScreen
import com.daksh.focuslock.ui.settings.ContentSettingsScreen
import com.daksh.focuslock.ui.settings.PermissionsScreen
import com.daksh.focuslock.ui.settings.SettingsScreen
import com.daksh.focuslock.ui.statistics.StatisticsScreen

object Routes {
    const val ONBOARDING = "onboarding"
    const val DASHBOARD = "dashboard"
    const val SCHEDULES = "schedules"
    const val STATS = "stats"
    const val SETTINGS = "settings"
    const val EDIT = "edit/{id}"
    const val SESSION = "session"
    const val CONTENT = "content"
    const val PERMISSIONS = "permissions"
    const val ABOUT = "about"
    fun edit(id: Long) = "edit/$id"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun FocusLockRoot(graph: AppGraph, prefs: Prefs) {
    val nav = rememberNavController()
    val start = remember { if (prefs.onboardingDone) Routes.DASHBOARD else Routes.ONBOARDING }
    val tabs = listOf(
        Tab(Routes.DASHBOARD, "Dashboard", Icons.Filled.Home),
        Tab(Routes.SCHEDULES, "Schedules", Icons.Filled.Schedule),
        Tab(Routes.STATS, "Statistics", Icons.Filled.BarChart),
        Tab(Routes.SETTINGS, "Settings", Icons.Filled.Settings)
    )
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val navigate: (String) -> Unit = { nav.navigate(it) }

    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo(Routes.DASHBOARD) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = start, modifier = Modifier.padding(pad)) {
            composable(Routes.ONBOARDING) {
                OnboardingScreen(graph) {
                    nav.navigate(Routes.DASHBOARD) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                }
            }
            composable(Routes.DASHBOARD) { DashboardScreen(graph, navigate) }
            composable(Routes.SCHEDULES) { SchedulesScreen(graph) { id -> nav.navigate(Routes.edit(id)) } }
            composable(Routes.STATS) { StatisticsScreen(graph) }
            composable(Routes.SETTINGS) { SettingsScreen(graph, navigate) }
            composable(
                Routes.EDIT,
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                ScheduleEditScreen(graph, entry.arguments?.getLong("id") ?: 0L) { nav.popBackStack() }
            }
            composable(Routes.SESSION) { SessionScreen(graph) { nav.popBackStack() } }
            composable(Routes.CONTENT) { ContentSettingsScreen(graph) { nav.popBackStack() } }
            composable(Routes.PERMISSIONS) { PermissionsScreen { nav.popBackStack() } }
            composable(Routes.ABOUT) { AboutScreen { nav.popBackStack() } }
        }
    }
}
