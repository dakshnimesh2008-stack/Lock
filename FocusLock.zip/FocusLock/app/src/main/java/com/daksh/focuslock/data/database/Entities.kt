package com.daksh.focuslock.data.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.daksh.focuslock.domain.model.FocusSchedule
import java.time.DayOfWeek

@Entity(tableName = "schedules")
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startMinute: Int,
    val endMinute: Int,
    val daysMask: Int,
    val enabled: Boolean,
    /** Comma-separated package names (package names never contain commas). */
    val packages: String,
    val description: String,
    val strict: Boolean,
    val createdAt: Long,
    val modifiedAt: Long
)

@Entity(
    tableName = "sessions",
    indices = [Index(value = ["scheduleId", "windowStart"], unique = true)]
)
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val scheduleId: Long,
    val scheduleName: String,
    val windowStart: Long,
    val windowEnd: Long,
    val lastSeenAt: Long
)

@Entity(tableName = "block_events")
data class BlockEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val packageName: String,
    val type: String,
    val confirmed: Boolean
)

fun ScheduleEntity.toDomain(): FocusSchedule = FocusSchedule(
    id = id,
    name = name,
    startMinute = startMinute,
    endMinute = endMinute,
    days = DayOfWeek.values().filter { (daysMask and (1 shl (it.value - 1))) != 0 }.toSet(),
    enabled = enabled,
    packages = if (packages.isBlank()) emptySet() else packages.split(",").toSet(),
    description = description,
    strict = strict,
    createdAt = createdAt,
    modifiedAt = modifiedAt
)

fun FocusSchedule.toEntity(): ScheduleEntity = ScheduleEntity(
    id = id,
    name = name,
    startMinute = startMinute,
    endMinute = endMinute,
    daysMask = days.fold(0) { acc, d -> acc or (1 shl (d.value - 1)) },
    enabled = enabled,
    packages = packages.sorted().joinToString(","),
    description = description,
    strict = strict,
    createdAt = createdAt,
    modifiedAt = modifiedAt
)
