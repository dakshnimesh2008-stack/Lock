package com.daksh.focuslock.accessibility

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import com.daksh.focuslock.receiver.ScheduleReceiver
import java.time.Instant
import java.time.ZoneId

/**
 * One inexact alarm for the next schedule boundary (start or end). Blocking itself never waits for this alarm:
 * the accessibility service evaluates the current time on every event. The alarm only refreshes session records.
 * Inexact alarms need no special permission on any API level, so no exact-alarm permission is requested.
 */
object AlarmScheduler {
    fun reschedule(ctx: Context, schedules: List<FocusSchedule>, now: Instant, zone: ZoneId) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            ctx, 1,
            Intent(ctx, ScheduleReceiver::class.java).setAction(ScheduleReceiver.ACTION_BOUNDARY),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val next = schedules.mapNotNull { ScheduleEvaluator.nextBoundary(it, now, zone) }.minOrNull()
        if (next == null) {
            am.cancel(pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.toEpochMilli(), pi)
        }
    }
}
