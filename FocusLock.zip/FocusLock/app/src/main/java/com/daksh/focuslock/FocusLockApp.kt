package com.daksh.focuslock

import android.app.Application
import android.content.Context
import com.daksh.focuslock.accessibility.AlarmScheduler
import com.daksh.focuslock.data.database.FocusDatabase
import com.daksh.focuslock.data.datastore.Prefs
import com.daksh.focuslock.data.datastore.PrefsRepository
import com.daksh.focuslock.data.repository.AppsRepository
import com.daksh.focuslock.data.repository.HistoryRepository
import com.daksh.focuslock.data.repository.ScheduleRepository
import com.daksh.focuslock.domain.blocking.BlockingEngine
import com.daksh.focuslock.domain.content.ContentBlocker
import com.daksh.focuslock.util.SystemTimeSource
import com.daksh.focuslock.util.TimeSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class FocusLockApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
    }
}

val Context.graph: AppGraph get() = (applicationContext as FocusLockApp).graph

/** Manual dependency container (DI framework not justified for this size). */
class AppGraph(context: Context) {
    val appContext: Context = context.applicationContext
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val time: TimeSource = SystemTimeSource

    val db: FocusDatabase by lazy { FocusDatabase.build(appContext) }
    val prefs: PrefsRepository by lazy { PrefsRepository(appContext) }
    val scheduleRepo: ScheduleRepository by lazy { ScheduleRepository(db.scheduleDao(), time) }
    val historyRepo: HistoryRepository by lazy { HistoryRepository(db.sessionDao(), db.blockEventDao()) }
    val appsRepo: AppsRepository by lazy { AppsRepository(appContext) }

    val engine = BlockingEngine(appContext.packageName)
    val contentBlocker = ContentBlocker()

    /** null until DataStore has delivered its first value. */
    val prefsState: StateFlow<Prefs?> =
        prefs.flow.map<Prefs, Prefs?> { it }.stateIn(appScope, SharingStarted.Eagerly, null)

    private val mutex = Mutex()

    init {
        appScope.launch {
            scheduleRepo.schedules.collect { engine.updateSchedules(it) }
        }
    }

    /** Recomputes everything derived from time: engine state, session records, next alarm. Safe to call often. */
    suspend fun runMaintenance() = withContext(Dispatchers.IO) {
        mutex.withLock {
            val list = scheduleRepo.getAll()
            engine.updateSchedules(list)
            val now = time.now()
            val zone = time.zone()
            historyRepo.closeEnded(now.toEpochMilli())
            historyRepo.sync(engine.getActiveRules(now, zone), now.toEpochMilli())
            AlarmScheduler.reschedule(appContext, list, now, zone)
        }
    }
}
