@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalCoroutinesApi::class)

package com.daksh.focuslock.ui.dashboard

import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.accessibility.ServiceState
import com.daksh.focuslock.data.repository.labelOf
import com.daksh.focuslock.domain.model.ActiveRule
import com.daksh.focuslock.domain.model.BlockRecord
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.model.SessionRecord
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import com.daksh.focuslock.domain.usecase.Stats
import com.daksh.focuslock.domain.usecase.StatsCalculator
import com.daksh.focuslock.ui.components.AgoText
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.FocusRing
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.components.StatTile
import com.daksh.focuslock.ui.components.StatusLine
import com.daksh.focuslock.ui.navigation.Routes
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.ui.util.openSettings
import com.daksh.focuslock.ui.util.rememberPermState
import com.daksh.focuslock.util.formatClock
import com.daksh.focuslock.util.formatDayTime
import com.daksh.focuslock.util.formatMinutes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant

data class HomeState(
    val rules: List<ActiveRule> = emptyList(),
    val next: Pair<FocusSchedule, Instant>? = null,
    val stats: Stats = Stats(),
    val selectedPackages: Set<String> = emptySet(),
    val scheduleCount: Int = 0,
    val sessions: List<SessionRecord> = emptyList(),
    val events: List<BlockRecord> = emptyList()
)

class HomeViewModel(private val g: AppGraph) : ViewModel() {

    /**
     * Event-driven recompute: emits now, then sleeps until the next schedule boundary.
     * While a session is active it also wakes once a minute so "focus today" advances. No fixed-rate polling otherwise.
     */
    private fun ticks(schedules: List<FocusSchedule>) = flow {
        while (true) {
            emit(Unit)
            val now = g.time.now()
            val zone = g.time.zone()
            val next = schedules.mapNotNull { ScheduleEvaluator.nextBoundary(it, now, zone) }.minOrNull() ?: break
            val active = schedules.any { ScheduleEvaluator.isActive(it, now, zone) }
            val untilNext = next.toEpochMilli() - now.toEpochMilli() + 50
            delay((if (active) minOf(untilNext, 60_000L) else untilNext).coerceIn(1_000L, 6 * 3_600_000L))
        }
    }

    val state: StateFlow<HomeState> = g.scheduleRepo.schedules.flatMapLatest { sch ->
        combine(g.historyRepo.sessions, g.historyRepo.events, ticks(sch)) { ses, ev, _ ->
            val now = g.time.now()
            val zone = g.time.zone()
            val rules = sch.mapNotNull { s -> ScheduleEvaluator.activeWindow(s, now, zone)?.let { ActiveRule(s, it) } }
            val next = sch.filter { it.enabled }
                .mapNotNull { s -> ScheduleEvaluator.nextStart(s, now, zone)?.let { s to it } }
                .minByOrNull { it.second }
            HomeState(
                rules = rules,
                next = next,
                stats = StatsCalculator.compute(ses, ev, now.toEpochMilli(), zone),
                selectedPackages = sch.filter { it.enabled }.flatMap { it.packages }.toSet(),
                scheduleCount = sch.size,
                sessions = ses,
                events = ev
            )
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeState())

    fun deleteHistory() {
        viewModelScope.launch { g.historyRepo.deleteAll() }
    }
}

@Composable
fun DashboardScreen(graph: AppGraph, onNavigate: (String) -> Unit) {
    val vm = graphViewModel(graph) { HomeViewModel(it) }
    val st by vm.state.collectAsStateWithLifecycle()
    val perm = rememberPermState()
    val health by ServiceState.health.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val recent = remember(st.events) {
        st.events.filter { it.type != "OVERRIDE" }.take(5).map {
            val time = formatDayTime(Instant.ofEpochMilli(it.timestamp))
            "$time · ${labelOf(ctx, it.packageName)} · ${it.type}" + if (it.confirmed) "" else " (screen not shown)"
        }
    }
    val serviceOk = perm.accessibilityEnabled && perm.serviceRunning

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("FOCUS LOCK") }
        if (!serviceOk) {
            item {
                FLCard(onClick = { ctx.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) }) {
                    Text("Blocking is OFF", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
                    Muted(
                        if (!perm.accessibilityEnabled) "The Accessibility service is disabled. Tap to open Accessibility settings."
                        else "Enabled in settings but not connected. Tap, switch FOCUS LOCK off and on again."
                    )
                }
            }
        }
        item {
            val rule = st.rules.minByOrNull { it.window.end }
            FLCard(onClick = { onNavigate(Routes.SESSION) }) {
                if (rule != null) {
                    Text("FOCUS ACTIVE · ${rule.schedule.name}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        FocusRing(rule.window.start.toEpochMilli(), rule.window.end.toEpochMilli())
                    }
                    Muted("until ${formatClock(rule.window.end)}")
                } else {
                    Text("No active session", style = MaterialTheme.typography.titleLarge)
                    val n = st.next
                    Muted(
                        when {
                            st.scheduleCount == 0 -> "No schedules yet."
                            n != null -> "Next: ${n.first.name} · ${formatDayTime(n.second)}"
                            else -> "No upcoming session (all schedules disabled)."
                        }
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Focus today", formatMinutes(st.stats.todayFocusMs / 60000), Modifier.weight(1f))
                StatTile("Blocked apps", st.selectedPackages.size.toString(), Modifier.weight(1f))
                StatTile("Attempts today", st.stats.attemptsToday.toString(), Modifier.weight(1f))
            }
        }
        item {
            FLCard(onClick = { onNavigate(Routes.PERMISSIONS) }) {
                Text("Accessibility service", style = MaterialTheme.typography.titleMedium)
                StatusLine(perm.accessibilityEnabled, "Enabled in Android settings")
                StatusLine(perm.serviceRunning, "Connected")
                AgoText("Last event ", health.lastEventAt, "No events seen since the service connected")
                health.lastFailure?.let { Muted("Last failure: $it") }
                if (health.lastCrash != null) Muted("App crashed before: ${health.lastCrash}")
            }
        }
        if (recent.isNotEmpty()) {
            item {
                FLCard {
                    Text("Recent events", style = MaterialTheme.typography.titleMedium)
                    recent.forEach { Muted(it) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onNavigate(Routes.edit(0)) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Text("  New schedule")
                }
                OutlinedButton(onClick = { onNavigate(Routes.SCHEDULES) }, modifier = Modifier.weight(1f)) { Text("Schedules") }
            }
        }
    }
}
