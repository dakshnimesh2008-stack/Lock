@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.repository.labelOf
import com.daksh.focuslock.domain.model.ActiveRule
import com.daksh.focuslock.domain.model.BlockRecord
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.model.SessionRecord
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import com.daksh.focuslock.domain.usecase.Stats
import com.daksh.focuslock.domain.usecase.StatsCalculator
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.components.StatTile
import com.daksh.focuslock.ui.components.StatusLine
import com.daksh.focuslock.ui.navigation.Routes
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.ui.util.rememberNowMs
import com.daksh.focuslock.ui.util.rememberPermState
import com.daksh.focuslock.util.formatClock
import com.daksh.focuslock.util.formatDayTime
import com.daksh.focuslock.util.formatDuration
import com.daksh.focuslock.util.formatMinutes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant

data class HomeState(
    val rules: List<ActiveRule> = emptyList(),
    val next: Pair<FocusSchedule, Instant>? = null,
    val stats: Stats = Stats(),
    val selectedPackages: Set<String> = emptySet(),
    val scheduleCount: Int = 0,
    val sessions: List<SessionRecord> = emptyList(),
    val events: List<BlockRecord> = emptyList()
)

class HomeViewModel(private val g: AppGraph) : ViewModel() {
    private val tick = flow { while (true) { emit(Unit); delay(5000) } }

    val state: StateFlow<HomeState> = combine(
        g.scheduleRepo.schedules, g.historyRepo.sessions, g.historyRepo.events, tick
    ) { sch, ses, ev, _ ->
        val now = g.time.now()
        val zone = g.time.zone()
        val rules = sch.mapNotNull { s -> ScheduleEvaluator.activeWindow(s, now, zone)?.let { ActiveRule(s, it) } }
        val next = sch.filter { it.enabled }
            .mapNotNull { s -> ScheduleEvaluator.nextStart(s, now, zone)?.let { s to it } }
            .minByOrNull { it.second }
        HomeState(
            rules = rules,
            next = next,
            stats = StatsCalculator.compute(ses, ev, now.toEpochMilli(), zone),
            selectedPackages = sch.filter { it.enabled }.flatMap { it.packages }.toSet(),
            scheduleCount = sch.size,
            sessions = ses,
            events = ev
        )
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeState())

    fun deleteHistory() {
        viewModelScope.launch { g.historyRepo.deleteAll() }
    }
}

@Composable
fun DashboardScreen(graph: AppGraph, onNavigate: (String) -> Unit) {
    val vm = graphViewModel(graph) { HomeViewModel(it) }
    val st by vm.state.collectAsStateWithLifecycle()
    val perm = rememberPermState()
    val now by rememberNowMs()
    val ctx = LocalContext.current

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("FOCUS LOCK", "Block distractions on your schedule") }
        item {
            val rule = st.rules.minByOrNull { it.window.end }
            FLCard(onClick = { onNavigate(Routes.SESSION) }) {
                if (rule != null) {
                    Text("FOCUS ACTIVE", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                    Text(rule.schedule.name, style = MaterialTheme.typography.titleLarge)
                    Text(
                        formatDuration(rule.window.end.toEpochMilli() - now),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold
                    )
                    Muted("until ${formatClock(rule.window.end)}")
                } else {
                    Text("No active session", style = MaterialTheme.typography.titleLarge)
                    Muted(
                        if (st.scheduleCount == 0) "You haven't created a schedule yet."
                        else "Nothing is being blocked right now."
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Focus today", formatMinutes(st.stats.todayFocusMs / 60000), Modifier.weight(1f))
                StatTile("Sessions done", st.stats.completedToday.toString(), Modifier.weight(1f))
                StatTile("Block attempts", st.stats.attemptsToday.toString(), Modifier.weight(1f))
            }
        }
        item {
            FLCard {
                Text("Next session", style = MaterialTheme.typography.titleMedium)
                val n = st.next
                if (n != null) Muted("${n.first.name} · ${formatDayTime(n.second)}")
                else Muted("None scheduled.")
            }
        }
        item {
            FLCard {
                Text("Blocked apps", style = MaterialTheme.typography.titleMedium)
                if (st.selectedPackages.isEmpty()) {
                    Muted("No apps selected in any enabled schedule.")
                } else {
                    val labels = remember(st.selectedPackages) {
                        st.selectedPackages.map { labelOf(ctx, it) }.sorted()
                    }
                    Muted("${labels.size} apps: " + labels.take(8).joinToString(", ") + if (labels.size > 8) "…" else "")
                }
            }
        }
        item {
            FLCard(onClick = { onNavigate(Routes.PERMISSIONS) }) {
                Text("Service health", style = MaterialTheme.typography.titleMedium)
                StatusLine(perm.accessibilityEnabled, "Accessibility enabled in Android settings")
                StatusLine(perm.serviceRunning, "Blocking service running")
                StatusLine(perm.batteryExempt, "Battery unrestricted (recommended)")
                if (!perm.accessibilityEnabled || !perm.serviceRunning) {
                    Muted("Blocking will NOT work until the service runs. Tap to set up.")
                }
            }
        }
        item {
            Button(onClick = { onNavigate(Routes.edit(0)) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("  Create schedule")
            }
        }
    }
}
