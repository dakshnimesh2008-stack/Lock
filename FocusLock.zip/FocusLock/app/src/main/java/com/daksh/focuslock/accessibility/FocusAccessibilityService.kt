package com.daksh.focuslock.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.datastore.Prefs
import com.daksh.focuslock.domain.content.ContentDecision
import com.daksh.focuslock.domain.content.ContentDetector
import com.daksh.focuslock.domain.content.ContentKind
import com.daksh.focuslock.domain.content.ContentPolicy
import com.daksh.focuslock.domain.content.Evidence
import com.daksh.focuslock.domain.model.ActiveRule
import com.daksh.focuslock.graph
import com.daksh.focuslock.ui.blocked.BlockedActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

/**
 * Foreground-app detection and (experimental) Shorts/Reels detection. Everything is local.
 * It never stores or sends node text, never reads typed text or messages, and returns early when no schedule is active.
 */
class FocusAccessibilityService : AccessibilityService() {

    private lateinit var graph: AppGraph
    private var lastBlockPkg: String? = null
    private var lastBlockAt = 0L
    private var lastScanAt = 0L
    private var lastSyncAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        graph = applicationContext.graph
        ServiceState.connected.value = true
        graph.appScope.launch { graph.runMaintenance() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (!::graph.isInitialized) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return // never react to ourselves (prevents launch loops)

        val nowMs = System.currentTimeMillis()
        val prefs = graph.prefsState.value ?: Prefs()
        if (nowMs < prefs.overrideUntil) return // user-configured emergency override is active

        val now = Instant.ofEpochMilli(nowMs)
        val zone = ZoneId.systemDefault()
        val rules = graph.engine.getActiveRules(now, zone)
        if (rules.isEmpty()) return

        if (nowMs - lastSyncAt > 60_000) {
            lastSyncAt = nowMs
            graph.appScope.launch(Dispatchers.IO) { graph.historyRepo.sync(rules, nowMs) }
        }

        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            graph.engine.shouldBlockLaunch(pkg, now, zone)
        ) {
            val rule = rules.filter { pkg in it.schedule.packages }
                .maxByOrNull { it.window.end.toEpochMilli() } ?: return
            block(pkg, rule, "APP", 2_000)
            return
        }

        if (prefs.blockShorts || prefs.blockReels) checkContent(pkg, nowMs, rules, prefs)
    }

    private fun checkContent(pkg: String, nowMs: Long, rules: List<ActiveRule>, prefs: Prefs) {
        val detector = graph.contentBlocker.detectorFor(pkg) ?: return
        if (nowMs - lastScanAt < 700) return
        lastScanAt = nowMs
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val result = graph.contentBlocker.detectSupportedContent(pkg, scan(root, detector))
        val decision = graph.contentBlocker.evaluateBlockingPolicy(
            result,
            ContentPolicy(prefs.blockShorts, prefs.blockReels, prefs.fallbackWholeApp),
            hasActiveSchedule = true
        )
        val rule = rules.maxByOrNull { it.window.end.toEpochMilli() } ?: return
        when (decision) {
            ContentDecision.BLOCK_CONTENT ->
                block(pkg, rule, if (result.kind == ContentKind.YOUTUBE_SHORTS) "SHORTS" else "REELS", 4_000)
            ContentDecision.BLOCK_APP_FALLBACK -> block(pkg, rule, "FALLBACK", 4_000)
            ContentDecision.ALLOW -> Unit
        }
    }

    /** Bounded tree walk that only COUNTS matches; no text is kept. */
    private fun scan(root: AccessibilityNodeInfo, d: ContentDetector): Evidence {
        var idHits = 0
        var labelHits = 0
        var visited = 0
        val stack = mutableListOf(root)
        while (stack.isNotEmpty() && visited < 300) {
            val n = stack.removeAt(stack.size - 1)
            visited++
            val id = n.viewIdResourceName?.lowercase()
            if (id != null && d.idHints.any { id.contains(it) }) idHits++
            val label = (n.text?.toString() ?: n.contentDescription?.toString())?.lowercase()
            if (label != null && label.length < 40 && d.labelHints.any { label.contains(it) }) labelHits++
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return Evidence(idHits, labelHits)
    }

    private fun block(pkg: String, rule: ActiveRule, kind: String, debounceMs: Long) {
        val now = System.currentTimeMillis()
        if (pkg == lastBlockPkg && now - lastBlockAt < debounceMs) return // duplicate-event protection
        lastBlockPkg = pkg
        lastBlockAt = now
        val ok = try {
            startActivity(
                Intent(this, BlockedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(BlockedActivity.EXTRA_PKG, pkg)
                    .putExtra(BlockedActivity.EXTRA_END, rule.window.end.toEpochMilli())
                    .putExtra(BlockedActivity.EXTRA_SCHEDULE, rule.schedule.name)
                    .putExtra(BlockedActivity.EXTRA_KIND, kind)
            )
            true
        } catch (t: Throwable) {
            Log.w(TAG, "Could not show blocking screen: ${t.javaClass.simpleName}")
            false
        }
        graph.appScope.launch(Dispatchers.IO) { graph.historyRepo.recordBlock(pkg, kind, ok) }
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        ServiceState.connected.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ServiceState.connected.value = false
        super.onDestroy()
    }

    private companion object {
        const val TAG = "FocusLockSvc"
    }
}
