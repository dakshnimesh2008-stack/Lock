package com.daksh.focuslock.domain.scheduler

import com.daksh.focuslock.domain.model.ActiveWindow
import com.daksh.focuslock.domain.model.FocusSchedule
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/** Central, pure schedule logic (java.time). No timers: callers pass the instant to evaluate. */
object ScheduleEvaluator {

    private fun startOf(date: LocalDate, s: FocusSchedule, zone: ZoneId): ZonedDateTime =
        date.atTime(s.startMinute / 60, s.startMinute % 60).atZone(zone)

    private fun endOf(date: LocalDate, s: FocusSchedule, zone: ZoneId): ZonedDateTime {
        val endDate = if (s.endMinute > s.startMinute) date else date.plusDays(1)
        return endDate.atTime(s.endMinute / 60, s.endMinute % 60).atZone(zone)
    }

    /** The window containing [instant], or null if the schedule is not active. */
    fun activeWindow(s: FocusSchedule, instant: Instant, zone: ZoneId): ActiveWindow? {
        if (!s.enabled || !s.isValid) return null
        val today = instant.atZone(zone).toLocalDate()
        for (d in listOf(today, today.minusDays(1))) {
            if (d.dayOfWeek !in s.days) continue
            val st = startOf(d, s, zone).toInstant()
            val en = endOf(d, s, zone).toInstant()
            if (!instant.isBefore(st) && instant.isBefore(en)) return ActiveWindow(st, en)
        }
        return null
    }

    fun isActive(s: FocusSchedule, instant: Instant, zone: ZoneId): Boolean =
        activeWindow(s, instant, zone) != null

    /** Next start or end boundary strictly after [after]. Used to arm the next alarm. */
    fun nextBoundary(s: FocusSchedule, after: Instant, zone: ZoneId): Instant? {
        if (!s.enabled || !s.isValid) return null
        val today = after.atZone(zone).toLocalDate()
        var best: Instant? = null
        for (offset in -1L..8L) {
            val d = today.plusDays(offset)
            if (d.dayOfWeek !in s.days) continue
            for (t in listOf(startOf(d, s, zone).toInstant(), endOf(d, s, zone).toInstant())) {
                if (t.isAfter(after) && (best == null || t.isBefore(best))) best = t
            }
        }
        return best
    }

    /** Next window start strictly after [after]. */
    fun nextStart(s: FocusSchedule, after: Instant, zone: ZoneId): Instant? {
        if (!s.enabled || !s.isValid) return null
        val today = after.atZone(zone).toLocalDate()
        var best: Instant? = null
        for (offset in 0L..8L) {
            val d = today.plusDays(offset)
            if (d.dayOfWeek !in s.days) continue
            val t = startOf(d, s, zone).toInstant()
            if (t.isAfter(after) && (best == null || t.isBefore(best))) best = t
        }
        return best
    }
}
