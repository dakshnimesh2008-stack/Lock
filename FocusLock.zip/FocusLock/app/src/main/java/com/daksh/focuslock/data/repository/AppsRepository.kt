package com.daksh.focuslock.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.TelecomManager
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.daksh.focuslock.domain.blocking.ProtectedPackages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val packageName: String, val label: String, val icon: ImageBitmap?)

fun labelOf(ctx: Context, pkg: String): String = runCatching {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
}.getOrDefault(pkg)

class AppsRepository(private val ctx: Context) {

    /** Launchable apps only (uses a <queries> LAUNCHER intent, not QUERY_ALL_PACKAGES). Excludes this app and essentials. */
    @Suppress("DEPRECATION")
    suspend fun loadLaunchableApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            pm.queryIntentActivities(intent, 0)
        }
        val excluded = protectedPackages() + ctx.packageName
        resolved
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName !in excluded }
            .map { ri ->
                val icon = runCatching { ri.loadIcon(pm).toBitmap(72, 72).asImageBitmap() }.getOrNull()
                AppInfo(ri.activityInfo.packageName, ri.loadLabel(pm).toString(), icon)
            }
            .sortedBy { it.label.lowercase() }
    }

    @Suppress("DEPRECATION")
    private fun protectedPackages(): Set<String> {
        val s = ProtectedPackages.fixed.toMutableSet()
        val pm = ctx.packageManager
        val home = runCatching {
            pm.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName
        }.getOrNull()
        if (home != null) s += home
        runCatching { ctx.getSystemService(TelecomManager::class.java)?.defaultDialerPackage }
            .getOrNull()?.let { s += it }
        return s
    }
}
