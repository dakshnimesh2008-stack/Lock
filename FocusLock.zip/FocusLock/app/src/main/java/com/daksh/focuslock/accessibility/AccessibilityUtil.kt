package com.daksh.focuslock.accessibility

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow

/** Live runtime state of the service (true only while Android has it connected). */
object ServiceState {
    val connected = MutableStateFlow(false)
}

object AccessibilityUtil {
    fun isEnabled(ctx: Context): Boolean {
        val enabledFlag = runCatching {
            Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
        }.getOrDefault(0)
        if (enabledFlag != 1) return false
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(ctx, FocusAccessibilityService::class.java)
        return list.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
}
