package com.daksh.focuslock.accessibility

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** Immutable service-health snapshot shown in the UI. All transitions are pure so they can be unit tested. */
data class ServiceHealth(
    val connected: Boolean = false,
    val connectedAt: Long = 0L,
    val lastEventAt: Long = 0L,
    val lastBlockAt: Long = 0L,
    val disconnects: Int = 0,
    val lastDisconnectAt: Long = 0L,
    val lastFailure: String? = null,
    val lastFailureAt: Long = 0L,
    val lastCrash: String? = null,
    val lastCrashAt: Long = 0L
) {
    fun onConnected(now: Long) = copy(connected = true, connectedAt = now)
    fun onDisconnected(now: Long) = copy(connected = false, disconnects = disconnects + 1, lastDisconnectAt = now)
    /** Throttled: only advances when at least [minGapMs] passed, so the UI isn't recomposed per event. */
    fun withEvent(now: Long, minGapMs: Long = 5_000) = if (now - lastEventAt >= minGapMs) copy(lastEventAt = now) else this
    fun withBlock(now: Long) = copy(lastBlockAt = now)
    fun withFailure(msg: String, now: Long) = copy(lastFailure = msg, lastFailureAt = now)
    fun withCrash(msg: String, now: Long) = copy(lastCrash = msg, lastCrashAt = now)
}

/** Runtime state of the service. Android may disconnect it at any time; we only report what we observe. */
object ServiceState {
    val connected = MutableStateFlow(false)
    val health = MutableStateFlow(ServiceHealth())

    private const val FILE = "service_health"

    fun loadPersisted(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        health.update {
            it.copy(
                lastFailure = p.getString("failure", null), lastFailureAt = p.getLong("failure_at", 0L),
                lastCrash = p.getString("crash", null), lastCrashAt = p.getLong("crash_at", 0L),
                disconnects = p.getInt("disconnects", it.disconnects),
                lastDisconnectAt = p.getLong("disconnect_at", it.lastDisconnectAt)
            )
        }
    }

    fun onConnected(now: Long) {
        connected.value = true
        health.update { it.onConnected(now) }
    }

    fun onDisconnected(ctx: Context, now: Long) {
        connected.value = false
        health.update { it.onDisconnected(now) }
        val h = health.value
        runCatching {
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
                .putInt("disconnects", h.disconnects).putLong("disconnect_at", now).apply()
        }
    }

    fun touchEvent(now: Long) { health.update { it.withEvent(now) } }
    fun touchBlock(now: Long) { health.update { it.withBlock(now) } }

    /** Reason text contains only class names and a source location, never user content. */
    fun describe(t: Throwable): String {
        val top = t.stackTrace.firstOrNull()
        return t.javaClass.simpleName + (if (top != null) " @ ${top.fileName}:${top.lineNumber}" else "")
    }

    fun recordFailure(ctx: Context, where: String, t: Throwable) {
        val msg = "$where: ${describe(t)}"
        val now = System.currentTimeMillis()
        health.update { it.withFailure(msg, now) }
        runCatching {
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("failure", msg).putLong("failure_at", now).apply()
        }
    }

    /** Called from the uncaught-exception handler: synchronous write because the process is about to die. */
    fun recordCrash(ctx: Context, t: Throwable) {
        val msg = describe(t)
        val now = System.currentTimeMillis()
        runCatching {
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("crash", msg).putLong("crash_at", now).commit()
        }
    }
}

object AccessibilityUtil {
    fun isEnabled(ctx: Context): Boolean {
        val enabledFlag = runCatching {
            Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
        }.getOrDefault(0)
        if (enabledFlag != 1) return false
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(ctx, FocusAccessibilityService::class.java)
        return list.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
}
