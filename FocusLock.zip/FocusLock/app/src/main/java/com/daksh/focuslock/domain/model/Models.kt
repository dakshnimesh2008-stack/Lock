package com.daksh.focuslock.domain.model

import java.time.DayOfWeek
import java.time.Instant

/**
 * A focus schedule. Interval semantics: START-INCLUSIVE, END-EXCLUSIVE.
 * If endMinute <= startMinute the schedule crosses midnight and belongs to the weekday it STARTS on.
 * startMinute == endMinute is invalid (never active).
 */
data class FocusSchedule(
    val id: Long = 0,
    val name: String,
    val startMinute: Int,
    val endMinute: Int,
    val days: Set<DayOfWeek>,
    val enabled: Boolean = true,
    val packages: Set<String> = emptySet(),
    val description: String = "",
    val strict: Boolean = false,
    val createdAt: Long = 0,
    val modifiedAt: Long = 0
) {
    val isValid: Boolean get() = startMinute != endMinute && days.isNotEmpty()
    val crossesMidnight: Boolean get() = endMinute < startMinute
}

data class ActiveWindow(val start: Instant, val end: Instant)

data class ActiveRule(val schedule: FocusSchedule, val window: ActiveWindow)

data class SessionRecord(
    val scheduleId: Long,
    val scheduleName: String,
    val windowStart: Long,
    val windowEnd: Long,
    val lastSeenAt: Long
) {
    val focusedMs: Long get() = (minOf(lastSeenAt, windowEnd) - windowStart).coerceAtLeast(0)
    val completed: Boolean get() = lastSeenAt >= windowEnd
}

/** type: APP, SHORTS, REELS, FALLBACK or OVERRIDE. confirmed = the blocking screen was actually started. */
data class BlockRecord(
    val timestamp: Long,
    val packageName: String,
    val type: String,
    val confirmed: Boolean
)
