package com.daksh.focuslock.domain.blocking

/** Essential system/emergency packages that are never blocked, even if somehow selected. */
object ProtectedPackages {
    val fixed: Set<String> = setOf(
        "com.android.settings",
        "com.android.systemui",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.dialer",
        "com.google.android.dialer",
        "com.samsung.android.dialer",
        "com.android.incallui",
        "com.samsung.android.incallui",
        "com.android.emergency",
        "com.google.android.apps.safetyhub",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller"
    )
}
