package com.daksh.focuslock.ui.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.accessibility.AccessibilityUtil
import com.daksh.focuslock.accessibility.ServiceState
import kotlinx.coroutines.delay

@Composable
inline fun <reified VM : ViewModel> graphViewModel(
    graph: AppGraph,
    key: String? = null,
    crossinline build: (AppGraph) -> VM
): VM = viewModel(
    key = key,
    factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = build(graph) as T
    }
)

@Composable
fun rememberNowMs(): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        value = System.currentTimeMillis()
        delay(1000)
    }
}

data class PermState(
    val accessibilityEnabled: Boolean,
    val serviceRunning: Boolean,
    val batteryExempt: Boolean
)

/** Re-evaluated every time the app returns to the foreground (e.g. after the user visits Android settings). */
@Composable
fun rememberPermState(): PermState {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, ev -> if (ev == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val running by ServiceState.connected.collectAsState()
    val enabled = remember(tick) { AccessibilityUtil.isEnabled(ctx) }
    val battery = remember(tick) {
        runCatching {
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        }.getOrDefault(false)
    }
    return PermState(enabled, running, battery)
}

/** Opens a settings screen; falls back to general Settings, then does nothing (never crashes). */
fun Context.openSettings(action: String) {
    val tryStart = { i: Intent ->
        runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
    }
    if (!tryStart(Intent(action))) tryStart(Intent(Settings.ACTION_SETTINGS))
}

fun Context.openAppDetails() {
    runCatching {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

fun isReducedMotion(ctx: Context): Boolean =
    Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
