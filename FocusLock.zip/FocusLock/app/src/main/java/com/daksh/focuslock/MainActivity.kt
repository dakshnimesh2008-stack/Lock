package com.daksh.focuslock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.daksh.focuslock.data.datastore.ThemeMode
import com.daksh.focuslock.ui.navigation.FocusLockRoot
import com.daksh.focuslock.ui.theme.FocusLockTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val graph = applicationContext.graph
        setContent {
            val prefs by graph.prefsState.collectAsStateWithLifecycle()
            val p = prefs
            FocusLockTheme(p?.theme ?: ThemeMode.DARK) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (p != null) FocusLockRoot(graph, p)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Recover after process death / manual time change while the app was closed.
        lifecycleScope.launch { applicationContext.graph.runMaintenance() }
    }
}
