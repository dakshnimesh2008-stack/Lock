package com.daksh.focuslock.domain.scheduler

import com.daksh.focuslock.domain.model.FocusSchedule
import java.time.Instant
import java.time.ZoneId

/**
 * Strict mode = in-app restriction only. While a strict schedule is active the app refuses to edit,
 * disable or delete it. It is NOT tamper-proof: the user can still disable the accessibility service,
 * force-stop or uninstall the app in Android settings. That is intentional (no device admin tricks).
 */
object StrictPolicy {
    fun isLocked(s: FocusSchedule, instant: Instant, zone: ZoneId): Boolean =
        s.strict && ScheduleEvaluator.isActive(s, instant, zone)

    fun canModify(s: FocusSchedule, instant: Instant, zone: ZoneId): Boolean = !isLocked(s, instant, zone)
}

class StrictLockedException :
    Exception("Strict session is active. This schedule can't be changed until it ends.")
