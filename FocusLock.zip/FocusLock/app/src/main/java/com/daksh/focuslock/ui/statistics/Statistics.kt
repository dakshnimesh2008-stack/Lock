@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.statistics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.repository.labelOf
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.components.StatTile
import com.daksh.focuslock.ui.dashboard.HomeViewModel
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.util.formatMinutes
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StatisticsScreen(graph: AppGraph) {
    val vm = graphViewModel(graph) { HomeViewModel(it) }
    val st by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val s = st.stats
    val max = (s.week.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
    val nowMs = System.currentTimeMillis()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Statistics", "Stored only on this device") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Focus today", formatMinutes(s.todayFocusMs / 60000), Modifier.weight(1f))
                StatTile("Completed", s.completedSessions.toString(), Modifier.weight(1f))
            }
        }
        item {
            FLCard {
                Text("Last 7 days", style = MaterialTheme.typography.titleMedium)
                Row(
                    Modifier.fillMaxWidth().height(140.dp).padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    s.week.forEach { (day, ms) ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${ms / 60000}m", style = MaterialTheme.typography.labelSmall)
                            Box(
                                Modifier.fillMaxWidth().height((80 * ms.toFloat() / max).dp.coerceAtLeast(3.dp))
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Text(day.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault()), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        item {
            FLCard {
                Text("Blocking", style = MaterialTheme.typography.titleMedium)
                Muted("Attempts: ${s.attempts}. Blocking screen shown: ${s.confirmed}.")
                Muted("\"Shown\" means Android accepted the request to open the blocking screen. It can't prove the app stayed unusable.")
                if (s.topApps.isNotEmpty()) {
                    Text("Most blocked", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                    s.topApps.forEach { (pkg, n) -> Muted("${labelOf(ctx, pkg)} — $n") }
                }
            }
        }
        item {
            FLCard {
                Text("Session history", style = MaterialTheme.typography.titleMedium)
                if (st.sessions.isEmpty()) Muted("No sessions recorded yet.")
                st.sessions.take(20).forEach { r ->
                    val date = DateTimeFormatter.ofPattern("EEE d MMM HH:mm")
                        .format(Instant.ofEpochMilli(r.windowStart).atZone(ZoneId.systemDefault()))
                    val status = when {
                        r.completed -> "Completed"
                        nowMs < r.windowEnd -> "In progress"
                        else -> "Interrupted"
                    }
                    Muted("${r.scheduleName} · $date · ${formatMinutes(r.focusedMs / 60000)} · $status")
                }
                Muted("Durations are estimates: time is counted while this device was observed running.")
            }
        }
        item {
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete history") }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete all history?") },
            text = { Text("Sessions, block attempts and override records are removed from this device.") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.deleteHistory() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}
