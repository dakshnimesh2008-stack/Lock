package com.daksh.focuslock.util

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/** Injectable clock so logic can be tested without the real time. */
interface TimeSource {
    fun now(): Instant
    fun zone(): ZoneId
}

object SystemTimeSource : TimeSource {
    override fun now(): Instant = Instant.now()
    override fun zone(): ZoneId = ZoneId.systemDefault()
}

fun formatMinute(m: Int): String = "%02d:%02d".format(m / 60, m % 60)

fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

fun formatMinutes(min: Long): String = if (min >= 60) "${min / 60}h ${min % 60}m" else "${min}m"

fun formatClock(i: Instant): String =
    DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).format(i.atZone(ZoneId.systemDefault()))

fun formatDayTime(i: Instant): String =
    DateTimeFormatter.ofPattern("EEE HH:mm").format(i.atZone(ZoneId.systemDefault()))
