@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(graph: AppGraph, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Icon(Icons.Filled.Security, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(88.dp))
        Text("FOCUS LOCK", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Muted("Pick distracting apps, set a schedule, and stay focused.")
        FLCard {
            Text("How it works", style = MaterialTheme.typography.titleMedium)
            Muted("You create schedules with the apps to block. When one of those apps opens during a schedule, FOCUS LOCK shows a focus screen instead.")
        }
        FLCard {
            Text("Why Accessibility permission", style = MaterialTheme.typography.titleMedium)
            Muted("Android only lets an app know which app is in front through an Accessibility service. You turn it on yourself in Android settings. FOCUS LOCK uses it only to see the foreground app name. It does not read messages, passwords or typing, has no internet permission and keeps everything on this device.")
        }
        FLCard {
            Text("Honest limits", style = MaterialTheme.typography.titleMedium)
            Muted("This is not a security lock. You can always turn the service off, force-stop or uninstall the app. Some phones stop background apps, so check battery settings in Permissions.")
        }
        Button(
            onClick = { scope.launch { graph.prefs.setOnboardingDone(); onDone() } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Get started") }
    }
}
