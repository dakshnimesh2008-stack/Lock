package com.daksh.focuslock.domain.content

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ContentKind { YOUTUBE_SHORTS, INSTAGRAM_REELS }
enum class Confidence { NONE, UNCERTAIN, CONFIRMED }
enum class ContentDecision { ALLOW, BLOCK_CONTENT, BLOCK_APP_FALLBACK }

/** Counts only. Node text is compared and discarded, never stored or sent. */
data class Evidence(
    val idHits: Int,
    val labelHits: Int,
    /** Label nodes (or their parent) that are in the "selected" state, e.g. a selected bottom tab. */
    val selectedHits: Int = 0,
    val visited: Int = 0,
    val truncated: Boolean = false
)

data class Verdict(val confidence: Confidence, val reason: String)

data class ContentResult(val kind: ContentKind?, val confidence: Confidence, val reason: String = "")

data class ContentPolicy(
    val blockShorts: Boolean,
    val blockReels: Boolean,
    val fallbackWholeApp: Boolean
)

data class DetectionStatus(
    val kind: ContentKind? = null,
    val confidence: Confidence = Confidence.NONE,
    val reason: String = "",
    val lastDetectionAt: Long = 0L
)

/** Local diagnostic record: reason code and counts only. Kept in memory, last 30 entries. */
data class DetectionLogEntry(
    val at: Long,
    val kind: ContentKind?,
    val confidence: Confidence,
    val reason: String,
    val idHits: Int,
    val labelHits: Int,
    val selectedHits: Int,
    val visited: Int
)

/**
 * EXPERIMENTAL. Hints are guesses that can break with app versions/languages.
 * Reason codes: SELECTED_TAB, ID_AND_LABEL (confirmed); ID_ONLY (uncertain);
 * LABEL_ONLY, NO_SIGNAL, NO_SIGNAL_TRUNCATED, NO_WINDOW (none).
 * A label alone (e.g. a "Shorts" shelf or hashtag on an ordinary video page) never blocks.
 */
interface ContentDetector {
    val packageName: String
    val kind: ContentKind
    val idHints: List<String>
    val labelHints: List<String>

    fun classify(e: Evidence): Verdict = when {
        e.selectedHits >= 1 -> Verdict(Confidence.CONFIRMED, "SELECTED_TAB")
        e.idHits >= 1 && e.labelHits >= 1 -> Verdict(Confidence.CONFIRMED, "ID_AND_LABEL")
        e.idHits >= 1 -> Verdict(Confidence.UNCERTAIN, "ID_ONLY")
        e.labelHits >= 1 -> Verdict(Confidence.NONE, "LABEL_ONLY")
        e.truncated -> Verdict(Confidence.NONE, "NO_SIGNAL_TRUNCATED")
        else -> Verdict(Confidence.NONE, "NO_SIGNAL")
    }
}

class YouTubeShortsDetector : ContentDetector {
    override val packageName = "com.google.android.youtube"
    override val kind = ContentKind.YOUTUBE_SHORTS
    override val idHints = listOf("reel_", "shorts_")
    override val labelHints = listOf("shorts")
}

class InstagramReelsDetector : ContentDetector {
    override val packageName = "com.instagram.android"
    override val kind = ContentKind.INSTAGRAM_REELS
    override val idHints = listOf("clips_viewer", "reel_viewer", "clips_")
    override val labelHints = listOf("reels")
}

class ContentBlocker(
    private val detectors: List<ContentDetector> = listOf(YouTubeShortsDetector(), InstagramReelsDetector())
) {
    private val _status = MutableStateFlow(DetectionStatus())
    val statusFlow: StateFlow<DetectionStatus> = _status

    private val _log = MutableStateFlow<List<DetectionLogEntry>>(emptyList())
    val logFlow: StateFlow<List<DetectionLogEntry>> = _log

    fun detectorFor(packageName: String): ContentDetector? = detectors.firstOrNull { it.packageName == packageName }

    fun detectSupportedContent(packageName: String, evidence: Evidence, recordLog: Boolean = false): ContentResult {
        val d = detectorFor(packageName) ?: return ContentResult(null, Confidence.NONE, "UNSUPPORTED_APP")
        val v = d.classify(evidence)
        val now = System.currentTimeMillis()
        if (v.confidence != Confidence.NONE) {
            _status.value = DetectionStatus(d.kind, v.confidence, v.reason, now)
        }
        if (recordLog) {
            append(DetectionLogEntry(now, d.kind, v.confidence, v.reason, evidence.idHits, evidence.labelHits, evidence.selectedHits, evidence.visited))
        }
        return ContentResult(d.kind, v.confidence, v.reason)
    }

    /** The foreground window could not be read at all (no root node). Shown only in diagnostic log. */
    fun noteNoWindow(packageName: String, recordLog: Boolean) {
        if (!recordLog) return
        append(DetectionLogEntry(System.currentTimeMillis(), detectorFor(packageName)?.kind, Confidence.NONE, "NO_WINDOW", 0, 0, 0, 0))
    }

    private fun append(e: DetectionLogEntry) {
        val cur = _log.value
        // Collapse identical consecutive entries to keep the log readable and cheap.
        val last = cur.firstOrNull()
        if (last != null && last.reason == e.reason && last.confidence == e.confidence &&
            last.idHits == e.idHits && last.labelHits == e.labelHits && last.selectedHits == e.selectedHits
        ) return
        _log.value = (listOf(e) + cur).take(30)
    }

    fun clearLog() { _log.value = emptyList() }

    fun evaluateBlockingPolicy(result: ContentResult, policy: ContentPolicy, hasActiveSchedule: Boolean): ContentDecision {
        if (!hasActiveSchedule) return ContentDecision.ALLOW
        val kind = result.kind ?: return ContentDecision.ALLOW
        val enabled = when (kind) {
            ContentKind.YOUTUBE_SHORTS -> policy.blockShorts
            ContentKind.INSTAGRAM_REELS -> policy.blockReels
        }
        if (!enabled) return ContentDecision.ALLOW
        return when (result.confidence) {
            Confidence.CONFIRMED -> ContentDecision.BLOCK_CONTENT
            Confidence.UNCERTAIN ->
                if (policy.fallbackWholeApp) ContentDecision.BLOCK_APP_FALLBACK else ContentDecision.ALLOW
            Confidence.NONE -> ContentDecision.ALLOW
        }
    }

    fun getDetectionStatus(): DetectionStatus = _status.value

    fun resetDetectionState() {
        _status.value = DetectionStatus()
        _log.value = emptyList()
    }
}
