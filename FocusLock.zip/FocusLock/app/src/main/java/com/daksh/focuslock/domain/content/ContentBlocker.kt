package com.daksh.focuslock.domain.content

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ContentKind { YOUTUBE_SHORTS, INSTAGRAM_REELS }
enum class Confidence { NONE, UNCERTAIN, CONFIRMED }
enum class ContentDecision { ALLOW, BLOCK_CONTENT, BLOCK_APP_FALLBACK }

/** Counts only. We never keep or transmit node text; labels are compared and discarded. */
data class Evidence(val idHits: Int, val labelHits: Int)

data class ContentResult(val kind: ContentKind?, val confidence: Confidence)

data class ContentPolicy(
    val blockShorts: Boolean,
    val blockReels: Boolean,
    val fallbackWholeApp: Boolean
)

data class DetectionStatus(
    val kind: ContentKind? = null,
    val confidence: Confidence = Confidence.NONE,
    val lastDetectionAt: Long = 0L
)

/**
 * EXPERIMENTAL. View ids and labels are hints that can change with app versions/languages.
 * CONFIRMED needs both an id hint and a label hint. Id-only is UNCERTAIN (maybe another language).
 * Label-only is NONE (e.g. the always-visible "Shorts" tab).
 */
interface ContentDetector {
    val packageName: String
    val kind: ContentKind
    val idHints: List<String>
    val labelHints: List<String>

    fun classify(e: Evidence): Confidence = when {
        e.idHits >= 1 && e.labelHits >= 1 -> Confidence.CONFIRMED
        e.idHits >= 1 -> Confidence.UNCERTAIN
        else -> Confidence.NONE
    }
}

class YouTubeShortsDetector : ContentDetector {
    override val packageName = "com.google.android.youtube"
    override val kind = ContentKind.YOUTUBE_SHORTS
    override val idHints = listOf("reel_", "shorts_")
    override val labelHints = listOf("shorts")
}

class InstagramReelsDetector : ContentDetector {
    override val packageName = "com.instagram.android"
    override val kind = ContentKind.INSTAGRAM_REELS
    override val idHints = listOf("clips_viewer", "reel_viewer", "clips_")
    override val labelHints = listOf("reels")
}

class ContentBlocker(
    private val detectors: List<ContentDetector> = listOf(YouTubeShortsDetector(), InstagramReelsDetector())
) {
    private val _status = MutableStateFlow(DetectionStatus())
    val statusFlow: StateFlow<DetectionStatus> = _status

    fun detectorFor(packageName: String): ContentDetector? = detectors.firstOrNull { it.packageName == packageName }

    fun detectSupportedContent(packageName: String, evidence: Evidence): ContentResult {
        val d = detectorFor(packageName) ?: return ContentResult(null, Confidence.NONE)
        val c = d.classify(evidence)
        if (c != Confidence.NONE) {
            _status.value = DetectionStatus(d.kind, c, System.currentTimeMillis())
        }
        return ContentResult(d.kind, c)
    }

    fun evaluateBlockingPolicy(result: ContentResult, policy: ContentPolicy, hasActiveSchedule: Boolean): ContentDecision {
        if (!hasActiveSchedule) return ContentDecision.ALLOW
        val kind = result.kind ?: return ContentDecision.ALLOW
        val enabled = when (kind) {
            ContentKind.YOUTUBE_SHORTS -> policy.blockShorts
            ContentKind.INSTAGRAM_REELS -> policy.blockReels
        }
        if (!enabled) return ContentDecision.ALLOW
        return when (result.confidence) {
            Confidence.CONFIRMED -> ContentDecision.BLOCK_CONTENT
            Confidence.UNCERTAIN ->
                if (policy.fallbackWholeApp) ContentDecision.BLOCK_APP_FALLBACK else ContentDecision.ALLOW
            Confidence.NONE -> ContentDecision.ALLOW
        }
    }

    fun getDetectionStatus(): DetectionStatus = _status.value

    fun resetDetectionState() {
        _status.value = DetectionStatus()
    }
}
