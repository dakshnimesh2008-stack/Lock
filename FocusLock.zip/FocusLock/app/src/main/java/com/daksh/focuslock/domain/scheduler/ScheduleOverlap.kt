package com.daksh.focuslock.domain.scheduler

import com.daksh.focuslock.domain.model.FocusSchedule
import java.time.Instant
import java.time.ZoneId

/** Time-overlap check between schedules over the next [horizonDays] days (enabled flag ignored). */
object ScheduleOverlap {
    fun overlaps(a: FocusSchedule, b: FocusSchedule, from: Instant, zone: ZoneId, horizonDays: Long = 8): Boolean {
        val start = from.atZone(zone).toLocalDate().minusDays(1)
        val wa = (0L..horizonDays).mapNotNull { ScheduleEvaluator.windowOnDate(a, start.plusDays(it), zone) }
        val wb = (0L..horizonDays).mapNotNull { ScheduleEvaluator.windowOnDate(b, start.plusDays(it), zone) }
        return wa.any { x -> wb.any { y -> x.start.isBefore(y.end) && y.start.isBefore(x.end) } }
    }

    fun overlapping(draft: FocusSchedule, others: List<FocusSchedule>, from: Instant, zone: ZoneId): List<FocusSchedule> =
        others.filter { it.id != draft.id && overlaps(draft, it, from, zone) }
}
