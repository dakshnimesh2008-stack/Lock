package com.daksh.focuslock.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedules ORDER BY startMinute, id")
    fun observeAll(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM schedules")
    suspend fun all(): List<ScheduleEntity>

    @Query("SELECT * FROM schedules WHERE id = :id")
    suspend fun get(id: Long): ScheduleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: ScheduleEntity): Long

    @Query("DELETE FROM schedules WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY windowStart DESC LIMIT 1000")
    fun observeAll(): Flow<List<SessionEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(e: SessionEntity): Long

    @Query("UPDATE sessions SET lastSeenAt = :now WHERE scheduleId = :scheduleId AND windowStart = :windowStart AND lastSeenAt < :now")
    suspend fun touch(scheduleId: Long, windowStart: Long, now: Long)

    @Query("UPDATE sessions SET lastSeenAt = windowEnd WHERE lastSeenAt < windowEnd AND windowEnd <= :now AND (:now - windowEnd) <= :graceMs")
    suspend fun closeEnded(now: Long, graceMs: Long)

    @Query("DELETE FROM sessions")
    suspend fun deleteAll()
}

@Dao
interface BlockEventDao {
    @Query("SELECT * FROM block_events ORDER BY timestamp DESC LIMIT 3000")
    fun observeAll(): Flow<List<BlockEventEntity>>

    @Insert
    suspend fun insert(e: BlockEventEntity): Long

    @Query("DELETE FROM block_events")
    suspend fun deleteAll()
}
