package com.daksh.focuslock.ui.blocked

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.daksh.focuslock.data.datastore.Prefs
import com.daksh.focuslock.data.datastore.ThemeMode
import com.daksh.focuslock.data.repository.labelOf
import com.daksh.focuslock.graph
import com.daksh.focuslock.ui.theme.FocusLockTheme
import com.daksh.focuslock.ui.util.isReducedMotion
import com.daksh.focuslock.ui.util.rememberNowMs
import com.daksh.focuslock.util.formatClock
import com.daksh.focuslock.util.formatDuration
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate

data class BlockInfo(val pkg: String, val schedule: String, val endMs: Long, val kind: String)

class BlockedActivity : ComponentActivity() {
    private var info by mutableStateOf(BlockInfo("", "", 0L, "APP"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        readIntent(intent)
        // Back always leads HOME, never back into the blocked app (no loops, no trap).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
        val graph = applicationContext.graph
        setContent {
            val prefs by graph.prefsState.collectAsStateWithLifecycle()
            val p = prefs ?: Prefs()
            FocusLockTheme(prefs?.theme ?: ThemeMode.DARK) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    BlockedScreen(info, p, onHome = { goHome() }, onOverride = { useOverride() }, onExpired = { finish() })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(i: Intent) {
        info = BlockInfo(
            pkg = i.getStringExtra(EXTRA_PKG) ?: "",
            schedule = i.getStringExtra(EXTRA_SCHEDULE) ?: "",
            endMs = i.getLongExtra(EXTRA_END, 0L),
            kind = i.getStringExtra(EXTRA_KIND) ?: "APP"
        )
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun useOverride() {
        val g = applicationContext.graph
        val pkg = info.pkg
        lifecycleScope.launch {
            g.prefs.setOverrideUntil(System.currentTimeMillis() + OVERRIDE_MS)
            g.historyRepo.recordBlock(pkg, "OVERRIDE", true) // usage is recorded locally
            finish()
        }
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_END = "end"
        const val EXTRA_SCHEDULE = "schedule"
        const val EXTRA_KIND = "kind"
        const val OVERRIDE_MS = 5 * 60 * 1000L
    }
}

private val MESSAGES = listOf(
    "Small focused steps beat big distracted ones.",
    "You chose this for a reason. Stay with it.",
    "Future you will thank you.",
    "One thing at a time.",
    "The feed will still be there later."
)

@Composable
fun BlockedScreen(info: BlockInfo, prefs: Prefs, onHome: () -> Unit, onOverride: () -> Unit, onExpired: () -> Unit) {
    val ctx = LocalContext.current
    val now by rememberNowMs()
    val appLabel = if (info.pkg.isBlank()) "This app" else labelOf(ctx, info.pkg)
    val until = if (info.endMs > 0) formatClock(Instant.ofEpochMilli(info.endMs)) else ""
    val reason = when (info.kind) {
        "SHORTS" -> "YouTube Shorts are blocked by “${info.schedule}” until $until."
        "REELS" -> "Instagram Reels are blocked by “${info.schedule}” until $until."
        "FALLBACK" -> "$appLabel is blocked by “${info.schedule}” until $until because Shorts/Reels couldn't be detected reliably and you chose whole-app fallback."
        else -> "$appLabel is blocked by “${info.schedule}” until $until."
    }
    LaunchedEffect(info.endMs) {
        if (info.endMs > 0) {
            val wait = info.endMs - System.currentTimeMillis()
            if (wait > 0) delay(wait)
            onExpired() // interval over: leave, so the app opens normally
        }
    }
    val scale = if (isReducedMotion(ctx)) 1f else {
        val t = rememberInfiniteTransition(label = "pulse")
        val v by t.animateFloat(
            0.94f, 1.06f,
            infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "scale"
        )
        v
    }
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Filled.Security, contentDescription = "FOCUS LOCK shield",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(96.dp).scale(scale)
        )
        Spacer(Modifier.height(20.dp))
        Text("Focus session active", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(reason, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (info.endMs > 0) {
            Spacer(Modifier.height(16.dp))
            Text(formatDuration(info.endMs - now), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
        }
        if (prefs.motivation) {
            Spacer(Modifier.height(16.dp))
            Text(
                MESSAGES[LocalDate.now().dayOfYear % MESSAGES.size],
                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary
            )
        }
        Spacer(Modifier.height(28.dp))
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("Go to home screen") }
        if (prefs.emergencyOverride) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOverride, modifier = Modifier.fillMaxWidth()) {
                Text("Emergency: allow for 5 minutes")
            }
            Text("Use is recorded on this device.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
