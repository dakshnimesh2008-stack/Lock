@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.schedules

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimeInput
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.repository.AppInfo
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import com.daksh.focuslock.domain.scheduler.ScheduleOverlap
import com.daksh.focuslock.domain.scheduler.StrictLockedException
import com.daksh.focuslock.domain.scheduler.StrictPolicy
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.util.formatMinuteLocal
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.util.formatMinutes
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

private val WEEKDAYS = setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)
private val WEEKEND = setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)

private fun daysLabel(days: Set<DayOfWeek>): String = when {
    days.isEmpty() -> "No days"
    days.size == 7 -> "Every day"
    days == WEEKDAYS -> "Mon–Fri"
    days == WEEKEND -> "Sat–Sun"
    else -> days.sortedBy { it.value }.joinToString(" ") { it.getDisplayName(TextStyle.SHORT, Locale.getDefault()) }
}

class SchedulesViewModel(private val g: AppGraph) : ViewModel() {
    val schedules: StateFlow<List<FocusSchedule>> =
        g.scheduleRepo.schedules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun toggle(s: FocusSchedule, enabled: Boolean) {
        viewModelScope.launch {
            try {
                g.scheduleRepo.setEnabled(s.id, enabled)
                g.runMaintenance()
            } catch (e: StrictLockedException) {
                _message.value = e.message
            }
        }
    }

    fun clearMessage() { _message.value = null }
}

@Composable
fun SchedulesScreen(graph: AppGraph, onEdit: (Long) -> Unit) {
    val vm = graphViewModel(graph) { SchedulesViewModel(it) }
    val list by vm.schedules.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) {
        msg?.let { snack.showSnackbar(it); vm.clearMessage() }
    }
    // Evaluated once per list change (no per-second ticking): lock state and overlaps.
    val derived = remember(list) {
        val now = Instant.now()
        val zone = ZoneId.systemDefault()
        list.associate { s ->
            s.id to Pair(
                StrictPolicy.isLocked(s, now, zone),
                ScheduleOverlap.overlapping(s, list, now, zone).map { it.name }
            )
        }
    }
    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { onEdit(0L) }) { Icon(Icons.Filled.Add, contentDescription = "New schedule") }
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ScreenTitle("Schedules") }
            if (list.isEmpty()) {
                item { FLCard { Muted("No schedules yet. Tap + to create one.") } }
            }
            items(list, key = { it.id }) { s ->
                val (locked, overlaps) = derived[s.id] ?: (false to emptyList<String>())
                FLCard(onClick = { onEdit(s.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${formatMinuteLocal(ctx, s.startMinute)} – ${formatMinuteLocal(ctx, s.endMinute)}" +
                                    if (s.crossesMidnight) " (+1 day)" else "",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Muted(daysLabel(s.days) + " · ${s.packages.size} apps" + (if (s.strict) " · Strict" else "") + (if (locked) " · locked now" else ""))
                            if (overlaps.isNotEmpty()) {
                                Text("Overlaps: " + overlaps.joinToString(", "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                        Switch(checked = s.enabled, onCheckedChange = { vm.toggle(s, it) }, enabled = !locked)
                    }
                }
            }
        }
    }
}

class EditViewModel(private val g: AppGraph, private val id: Long) : ViewModel() {
    var draft by mutableStateOf<FocusSchedule?>(null)
        private set
    var locked by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
    val others: StateFlow<List<FocusSchedule>> =
        g.scheduleRepo.schedules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            val s = if (id == 0L) {
                FocusSchedule(name = "", startMinute = 9 * 60, endMinute = 10 * 60, days = WEEKDAYS)
            } else g.scheduleRepo.get(id)
            draft = s
            locked = s != null && StrictPolicy.isLocked(s, g.time.now(), g.time.zone())
        }
    }

    fun update(f: (FocusSchedule) -> FocusSchedule) { draft = draft?.let(f); error = null }

    /** Sets end = start + [minutes] (wraps past midnight). */
    fun preset(minutes: Int) = update { it.copy(endMinute = (it.startMinute + minutes) % 1440) }

    private fun validate(d: FocusSchedule): String? = when {
        d.startMinute == d.endMinute -> "Start and end time can't be the same."
        d.days.isEmpty() -> "Pick at least one day."
        d.packages.isEmpty() -> "Select at least one app to block."
        else -> null
    }

    fun save(onDone: () -> Unit) {
        val d = draft ?: return
        val problem = validate(d)
        if (problem != null) { error = problem; return }
        viewModelScope.launch {
            try {
                g.scheduleRepo.save(d.copy(name = d.name.trim().ifBlank { "Focus session" }))
                g.runMaintenance()
                onDone()
            } catch (e: StrictLockedException) {
                error = e.message
            }
        }
    }

    fun duplicate(onDone: () -> Unit) {
        val d = draft ?: return
        viewModelScope.launch {
            g.scheduleRepo.save(d.copy(id = 0, name = d.name.ifBlank { "Focus session" } + " (copy)", strict = false))
            g.runMaintenance()
            onDone()
        }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                g.scheduleRepo.delete(id)
                g.runMaintenance()
                onDone()
            } catch (e: StrictLockedException) {
                error = e.message
            }
        }
    }
}

@Composable
fun ScheduleEditScreen(graph: AppGraph, id: Long, onClose: () -> Unit) {
    val vm = graphViewModel(graph, key = "edit$id") { EditViewModel(it, id) }
    val ctx = LocalContext.current
    val others by vm.others.collectAsStateWithLifecycle()
    var picker by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val d = vm.draft
    if (d == null) { Box(Modifier.fillMaxSize()); return }

    if (picker) {
        BackHandler { picker = false }
        AppPicker(
            graph = graph,
            initial = d.packages,
            onCancel = { picker = false },
            onDone = { sel -> vm.update { it.copy(packages = sel) }; picker = false }
        )
        return
    }

    val enabled = !vm.locked
    val overlaps = remember(d.startMinute, d.endMinute, d.days, others) {
        ScheduleOverlap.overlapping(d, others, Instant.now(), ZoneId.systemDefault())
    }
    val summary = remember(d.startMinute, d.endMinute, d.days, d.packages.size) {
        if (d.startMinute == d.endMinute || d.days.isEmpty()) ""
        else daysLabel(d.days) + " · " + formatMinuteLocal(ctx, d.startMinute) + "–" + formatMinuteLocal(ctx, d.endMinute) +
            (if (d.crossesMidnight) " (next day)" else "") + " · " + formatMinutes(ScheduleEvaluator.durationMinutes(d).toLong()) +
            " · ${d.packages.size} apps"
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle(if (id == 0L) "New schedule" else "Edit schedule") }
        if (vm.locked) {
            item { FLCard { Text("Strict session running. This schedule can't be changed until it ends.") } }
        }
        item {
            OutlinedTextField(
                value = d.name, onValueChange = { v -> vm.update { it.copy(name = v.take(40)) } },
                label = { Text("Name") }, singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TimeCard("Start", d.startMinute, enabled, Modifier.weight(1f)) { m -> vm.update { it.copy(startMinute = m) } }
                TimeCard("End", d.endMinute, enabled, Modifier.weight(1f)) { m -> vm.update { it.copy(endMinute = m) } }
            }
        }
        item {
            Column {
                Muted("Duration from start")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("25 min" to 25, "45 min" to 45, "1 hour" to 60, "2 hours" to 120).forEach { (label, mins) ->
                        AssistChip(onClick = { vm.preset(mins) }, label = { Text(label) }, enabled = enabled)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                DayOfWeek.values().forEach { day ->
                    DayToggle(
                        letter = day.getDisplayName(TextStyle.NARROW, Locale.getDefault()),
                        selected = day in d.days,
                        enabled = enabled
                    ) { vm.update { s -> s.copy(days = if (day in s.days) s.days - day else s.days + day) } }
                }
            }
        }
        item {
            OutlinedButton(onClick = { picker = true }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                Text("Apps to block (${d.packages.size})")
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enabled", Modifier.weight(1f))
                Switch(d.enabled, { v -> vm.update { it.copy(enabled = v) } }, enabled = enabled)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Strict mode")
                    Muted("Locks editing, disabling and deleting while the session runs. Android settings can still switch the service off.")
                }
                Switch(d.strict, { v -> vm.update { it.copy(strict = v) } }, enabled = enabled)
            }
        }
        if (summary.isNotEmpty()) {
            item { FLCard { Text(summary, style = MaterialTheme.typography.bodyLarge) } }
        }
        if (overlaps.isNotEmpty()) {
            item {
                Text(
                    "Overlaps with: " + overlaps.joinToString(", ") { it.name } + ". Apps from both are blocked in the overlap.",
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
        vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onClose, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(onClick = { vm.save(onClose) }, enabled = enabled, modifier = Modifier.weight(1f)) { Text("Save") }
            }
        }
        if (id != 0L) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { vm.duplicate(onClose) }, modifier = Modifier.weight(1f)) { Text("Duplicate") }
                    TextButton(onClick = { confirmDelete = true }, enabled = enabled, modifier = Modifier.weight(1f)) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete schedule?") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(onClose) }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun TimeCard(label: String, minute: Int, enabled: Boolean, modifier: Modifier, onPick: (Int) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    FLCard(modifier = modifier, onClick = if (enabled) ({ open = true }) else null) {
        Muted(label)
        Text(formatMinuteLocal(ctx, minute), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    }
    if (open) {
        val is24 = android.text.format.DateFormat.is24HourFormat(ctx)
        val state = rememberTimePickerState(minute / 60, minute % 60, is24)
        var typing by remember { mutableStateOf(false) }
        Dialog(onDismissRequest = { open = false }) {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (typing) TimeInput(state = state) else TimePicker(state = state)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { typing = !typing }) { Text(if (typing) "Dial" else "Type") }
                        Row {
                            TextButton(onClick = { open = false }) { Text("Cancel") }
                            TextButton(onClick = { onPick(state.hour * 60 + state.minute); open = false }) { Text("OK") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayToggle(letter: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            letter,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun AppPicker(graph: AppGraph, initial: Set<String>, onCancel: () -> Unit, onDone: (Set<String>) -> Unit) {
    val apps by produceState<List<AppInfo>?>(null) { value = graph.appsRepo.loadLaunchableApps() }
    var sel by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    var debounced by remember { mutableStateOf("") }
    LaunchedEffect(query) { delay(200); debounced = query }
    val all = apps
    val filtered = remember(all, debounced) {
        all?.filter { it.label.contains(debounced, ignoreCase = true) } ?: emptyList()
    }
    val selectedNames = remember(all, sel) {
        all?.filter { it.packageName in sel }?.take(4)?.joinToString(", ") { it.label } ?: ""
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Select apps", "${sel.size} selected" + if (selectedNames.isNotEmpty()) " · $selectedNames" else "")
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            label = { Text("Search apps") }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        if (all == null) {
            Muted("Loading apps…")
        } else {
            Row {
                TextButton(onClick = { sel = sel + filtered.map { it.packageName } }) { Text("Select all (${filtered.size})") }
                TextButton(onClick = { sel = emptySet() }) { Text("Clear") }
            }
            LazyColumn(Modifier.weight(1f)) {
                items(filtered, key = { it.packageName }) { app ->
                    val checked = app.packageName in sel
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { sel = if (checked) sel - app.packageName else sel + app.packageName }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (app.icon != null) Image(app.icon, contentDescription = null, modifier = Modifier.size(36.dp))
                        else Box(Modifier.size(36.dp))
                        Text(app.label, Modifier.weight(1f).padding(horizontal = 12.dp))
                        Checkbox(checked = checked, onCheckedChange = null)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = { onDone(sel) }, modifier = Modifier.weight(1f)) { Text("Done") }
        }
    }
}
