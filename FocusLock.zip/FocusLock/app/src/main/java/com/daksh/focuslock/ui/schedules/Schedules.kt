@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.schedules

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.repository.AppInfo
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.scheduler.StrictLockedException
import com.daksh.focuslock.domain.scheduler.StrictPolicy
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.ui.util.rememberNowMs
import com.daksh.focuslock.util.formatMinute
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.format.TextStyle
import java.util.Locale

class SchedulesViewModel(private val g: AppGraph) : ViewModel() {
    val schedules: StateFlow<List<FocusSchedule>> =
        g.scheduleRepo.schedules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun toggle(s: FocusSchedule, enabled: Boolean) {
        viewModelScope.launch {
            try {
                g.scheduleRepo.setEnabled(s.id, enabled)
                g.runMaintenance()
            } catch (e: StrictLockedException) {
                _message.value = e.message
            }
        }
    }

    fun clearMessage() { _message.value = null }
}

@Composable
fun SchedulesScreen(graph: AppGraph, onEdit: (Long) -> Unit) {
    val vm = graphViewModel(graph) { SchedulesViewModel(it) }
    val list by vm.schedules.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val now by rememberNowMs()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) {
        msg?.let { snack.showSnackbar(it); vm.clearMessage() }
    }
    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { onEdit(0L) }) { Icon(Icons.Filled.Add, contentDescription = "Create schedule") }
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ScreenTitle("Schedules", "Each schedule blocks its own apps.") }
            if (list.isEmpty()) {
                item {
                    FLCard {
                        Text("No schedules yet", style = MaterialTheme.typography.titleMedium)
                        Muted("Tap + to create your first focus schedule.")
                    }
                }
            }
            items(list, key = { it.id }) { s ->
                val locked = StrictPolicy.isLocked(s, Instant.ofEpochMilli(now), java.time.ZoneId.systemDefault())
                FLCard(onClick = { onEdit(s.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${formatMinute(s.startMinute)} – ${formatMinute(s.endMinute)}" + if (s.crossesMidnight) " (+1 day)" else "",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Muted(
                                s.days.sortedBy { it.value }
                                    .joinToString(" ") { it.getDisplayName(TextStyle.SHORT, Locale.getDefault()) }
                            )
                            Muted("${s.packages.size} apps" + (if (s.strict) " · Strict" else "") + (if (locked) " (locked now)" else ""))
                        }
                        Switch(checked = s.enabled, onCheckedChange = { vm.toggle(s, it) }, enabled = !locked)
                    }
                }
            }
        }
    }
}

class EditViewModel(private val g: AppGraph, private val id: Long) : ViewModel() {
    var draft by mutableStateOf<FocusSchedule?>(null)
        private set
    var locked by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)

    init {
        viewModelScope.launch {
            val s = if (id == 0L) {
                FocusSchedule(
                    name = "", startMinute = 9 * 60, endMinute = 17 * 60,
                    days = setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)
                )
            } else g.scheduleRepo.get(id)
            draft = s
            locked = s != null && StrictPolicy.isLocked(s, g.time.now(), g.time.zone())
        }
    }

    fun update(f: (FocusSchedule) -> FocusSchedule) { draft = draft?.let(f) }

    fun save(onDone: () -> Unit) {
        val d = draft ?: return
        if (!d.isValid) { error = "Pick at least one day and different start and end times."; return }
        if (d.packages.isEmpty()) { error = "Select at least one app to block."; return }
        viewModelScope.launch {
            try {
                g.scheduleRepo.save(d.copy(name = d.name.ifBlank { "Focus session" }))
                g.runMaintenance()
                onDone()
            } catch (e: StrictLockedException) {
                error = e.message
            }
        }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                g.scheduleRepo.delete(id)
                g.runMaintenance()
                onDone()
            } catch (e: StrictLockedException) {
                error = e.message
            }
        }
    }
}

@Composable
fun ScheduleEditScreen(graph: AppGraph, id: Long, onClose: () -> Unit) {
    val vm = graphViewModel(graph, key = "edit$id") { EditViewModel(it, id) }
    var picker by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val d = vm.draft
    if (d == null) { Box(Modifier.fillMaxSize()) ; return }

    if (picker) {
        BackHandler { picker = false }
        AppPicker(
            graph = graph,
            initial = d.packages,
            onCancel = { picker = false },
            onDone = { sel -> vm.update { it.copy(packages = sel) }; picker = false }
        )
        return
    }

    val enabled = !vm.locked
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle(if (id == 0L) "New schedule" else "Edit schedule") }
        if (vm.locked) {
            item {
                FLCard {
                    Text("Strict session active", style = MaterialTheme.typography.titleMedium)
                    Muted("This schedule can't be edited, disabled or deleted until the current session ends.")
                }
            }
        }
        item {
            OutlinedTextField(
                value = d.name, onValueChange = { v -> vm.update { it.copy(name = v) } },
                label = { Text("Name") }, singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = d.description, onValueChange = { v -> vm.update { it.copy(description = v.take(120)) } },
                label = { Text("Description (optional)") }, enabled = enabled, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TimeField("Start", d.startMinute, enabled) { m -> vm.update { it.copy(startMinute = m) } }
                TimeField("End", d.endMinute, enabled) { m -> vm.update { it.copy(endMinute = m) } }
            }
            if (d.crossesMidnight) Muted("Ends the next day. Counts for the day it starts. Start is inclusive, end is exclusive.")
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                DayOfWeek.values().forEach { day ->
                    DayToggle(
                        letter = day.getDisplayName(TextStyle.NARROW, Locale.getDefault()),
                        selected = day in d.days,
                        enabled = enabled
                    ) { vm.update { s -> s.copy(days = if (day in s.days) s.days - day else s.days + day) } }
                }
            }
        }
        item {
            OutlinedButton(onClick = { picker = true }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                Text("Select apps (${d.packages.size})")
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Enabled")
                }
                Switch(d.enabled, { v -> vm.update { it.copy(enabled = v) } }, enabled = enabled)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Strict mode")
                    Muted("While active, this schedule can't be edited, paused or deleted in the app. Android settings can still disable the service.")
                }
                Switch(d.strict, { v -> vm.update { it.copy(strict = v) } }, enabled = enabled)
            }
        }
        vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
        item {
            Button(onClick = { vm.save(onClose) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("Save") }
        }
        item {
            TextButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        }
        if (id != 0L) {
            item {
                TextButton(onClick = { confirmDelete = true }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                    Text("Delete schedule", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete schedule?") },
            text = { Text("This can't be undone.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(onClose) }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun TimeField(label: String, minute: Int, enabled: Boolean, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, enabled = enabled) { Text("$label  ${formatMinute(minute)}") }
    if (open) {
        val state = rememberTimePickerState(minute / 60, minute % 60, true)
        Dialog(onDismissRequest = { open = false }) {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    TimePicker(state = state)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { open = false }) { Text("Cancel") }
                        TextButton(onClick = { onPick(state.hour * 60 + state.minute); open = false }) { Text("OK") }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayToggle(letter: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            letter,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun AppPicker(graph: AppGraph, initial: Set<String>, onCancel: () -> Unit, onDone: (Set<String>) -> Unit) {
    val apps by produceState<List<AppInfo>?>(null) { value = graph.appsRepo.loadLaunchableApps() }
    var sel by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    val all = apps
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Select apps", "${sel.size} selected")
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            label = { Text("Search apps") }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        if (all == null) {
            Muted("Loading apps…")
        } else {
            val filtered = all.filter { it.label.contains(query, ignoreCase = true) }
            Row {
                TextButton(onClick = { sel = sel + filtered.map { it.packageName } }) { Text("Select all (${filtered.size})") }
                TextButton(onClick = { sel = emptySet() }) { Text("Clear") }
            }
            Muted("FOCUS LOCK itself and essential phone/system apps are not listed.")
            LazyColumn(Modifier.weight(1f)) {
                items(filtered, key = { it.packageName }) { app ->
                    val checked = app.packageName in sel
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { sel = if (checked) sel - app.packageName else sel + app.packageName }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (app.icon != null) Image(app.icon, contentDescription = null, modifier = Modifier.size(36.dp))
                        else Box(Modifier.size(36.dp))
                        Text(app.label, Modifier.weight(1f).padding(horizontal = 12.dp))
                        Checkbox(checked = checked, onCheckedChange = null)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = { onDone(sel) }, modifier = Modifier.weight(1f)) { Text("Done") }
        }
    }
}
