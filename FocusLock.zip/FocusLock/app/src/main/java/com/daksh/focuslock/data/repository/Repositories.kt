package com.daksh.focuslock.data.repository

import com.daksh.focuslock.data.database.BlockEventDao
import com.daksh.focuslock.data.database.BlockEventEntity
import com.daksh.focuslock.data.database.ScheduleDao
import com.daksh.focuslock.data.database.SessionDao
import com.daksh.focuslock.data.database.SessionEntity
import com.daksh.focuslock.data.database.toDomain
import com.daksh.focuslock.data.database.toEntity
import com.daksh.focuslock.domain.model.ActiveRule
import com.daksh.focuslock.domain.model.BlockRecord
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.model.SessionRecord
import com.daksh.focuslock.domain.scheduler.StrictLockedException
import com.daksh.focuslock.domain.scheduler.StrictPolicy
import com.daksh.focuslock.util.TimeSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ScheduleRepository(private val dao: ScheduleDao, private val time: TimeSource) {

    val schedules: Flow<List<FocusSchedule>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun getAll(): List<FocusSchedule> = dao.all().map { it.toDomain() }

    suspend fun get(id: Long): FocusSchedule? = dao.get(id)?.toDomain()

    private fun checkNotLocked(s: FocusSchedule?) {
        if (s != null && StrictPolicy.isLocked(s, time.now(), time.zone())) throw StrictLockedException()
    }

    suspend fun save(s: FocusSchedule): Long {
        val existing = if (s.id != 0L) get(s.id) else null
        checkNotLocked(existing)
        val ts = time.now().toEpochMilli()
        return dao.upsert(s.copy(createdAt = existing?.createdAt ?: ts, modifiedAt = ts).toEntity())
    }

    suspend fun delete(id: Long) {
        checkNotLocked(get(id))
        dao.delete(id)
    }

    suspend fun setEnabled(id: Long, enabled: Boolean) {
        val s = get(id) ?: return
        checkNotLocked(s)
        dao.upsert(s.copy(enabled = enabled, modifiedAt = time.now().toEpochMilli()).toEntity())
    }
}

class HistoryRepository(private val sessionDao: SessionDao, private val eventDao: BlockEventDao) {

    val sessions: Flow<List<SessionRecord>> = sessionDao.observeAll().map { list ->
        list.map { SessionRecord(it.scheduleId, it.scheduleName, it.windowStart, it.windowEnd, it.lastSeenAt) }
    }

    val events: Flow<List<BlockRecord>> = eventDao.observeAll().map { list ->
        list.map { BlockRecord(it.timestamp, it.packageName, it.type, it.confirmed) }
    }

    /** Records/refreshes a session row for every active rule. "lastSeenAt" is when the device was last observed alive. */
    suspend fun sync(rules: List<ActiveRule>, nowMs: Long) {
        for (r in rules) {
            val ws = r.window.start.toEpochMilli()
            sessionDao.insertIgnore(
                SessionEntity(
                    scheduleId = r.schedule.id,
                    scheduleName = r.schedule.name,
                    windowStart = ws,
                    windowEnd = r.window.end.toEpochMilli(),
                    lastSeenAt = nowMs
                )
            )
            sessionDao.touch(r.schedule.id, ws, nowMs)
        }
    }

    /**
     * Marks sessions that just ended as fully completed, but only if we are running shortly after the end
     * (device was on). Sessions we only learn about much later keep their last observed time (interrupted).
     */
    suspend fun closeEnded(nowMs: Long) = sessionDao.closeEnded(nowMs, GRACE_MS)

    /** confirmed = the blocking screen start call succeeded. It does not prove the user could not bypass it. */
    suspend fun recordBlock(pkg: String, type: String, confirmed: Boolean) {
        eventDao.insert(
            BlockEventEntity(timestamp = System.currentTimeMillis(), packageName = pkg, type = type, confirmed = confirmed)
        )
    }

    suspend fun deleteAll() {
        sessionDao.deleteAll()
        eventDao.deleteAll()
    }

    companion object {
        const val GRACE_MS = 10 * 60 * 1000L
    }
}
