package com.daksh.focuslock.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.daksh.focuslock.ui.util.rememberNowMs
import com.daksh.focuslock.util.formatDuration

/** Static ring + countdown. Redrawn once per second; no infinite animation. Owns its own clock so parents don't recompose. */
@Composable
fun FocusRing(startMs: Long, endMs: Long, modifier: Modifier = Modifier) {
    val now by rememberNowMs()
    val total = (endMs - startMs).coerceAtLeast(1L)
    val remaining = (endMs - now).coerceIn(0L, total)
    val progress = remaining.toFloat() / total.toFloat()
    val track = MaterialTheme.colorScheme.outline
    val arc = MaterialTheme.colorScheme.primary
    Box(modifier.size(190.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val stroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            drawArc(track, 0f, 360f, false, style = stroke)
            drawArc(arc, -90f, 360f * progress, false, style = stroke)
        }
        Text(formatDuration(remaining), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    }
}

/** Small text that refreshes itself, e.g. "12s ago". */
@Composable
fun AgoText(prefix: String, timestamp: Long, never: String) {
    val now by rememberNowMs()
    val text = if (timestamp <= 0L) never else {
        val s = ((now - timestamp) / 1000).coerceAtLeast(0)
        prefix + when {
            s < 60 -> "${s}s ago"
            s < 3600 -> "${s / 60}m ago"
            else -> "${s / 3600}h ago"
        }
    }
    Muted(text)
}
