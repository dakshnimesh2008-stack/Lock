@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.settings

import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.accessibility.ServiceState
import com.daksh.focuslock.ui.components.AgoText
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import com.daksh.focuslock.data.datastore.Prefs
import com.daksh.focuslock.data.datastore.ThemeMode
import com.daksh.focuslock.domain.content.Confidence
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.components.StatusLine
import com.daksh.focuslock.ui.navigation.Routes
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.ui.util.openAppDetails
import com.daksh.focuslock.ui.util.openSettings
import com.daksh.focuslock.ui.util.rememberPermState
import kotlinx.coroutines.launch

class SettingsViewModel(private val g: AppGraph) : ViewModel() {
    val prefs = g.prefsState
    fun theme(m: ThemeMode) = viewModelScope.launch { g.prefs.setTheme(m) }
    fun shorts(v: Boolean) = viewModelScope.launch { g.prefs.setBlockShorts(v) }
    fun reels(v: Boolean) = viewModelScope.launch { g.prefs.setBlockReels(v) }
    fun fallback(v: Boolean) = viewModelScope.launch { g.prefs.setFallback(v) }
    fun setOverride(v: Boolean) = viewModelScope.launch { g.prefs.setEmergencyOverride(v) }
    fun motivation(v: Boolean) = viewModelScope.launch { g.prefs.setMotivation(v) }
    fun diagnostics(v: Boolean) = viewModelScope.launch { g.prefs.setDiagnostics(v) }
    fun deleteHistory() = viewModelScope.launch { g.historyRepo.deleteAll() }
}

@Composable
private fun SwitchRow(title: String, detail: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (detail != null) Muted(detail)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun LinkRow(title: String, onClick: () -> Unit) {
    FLCard(onClick = onClick) { Text(title, style = MaterialTheme.typography.titleMedium) }
}

@Composable
fun SettingsScreen(graph: AppGraph, onNavigate: (String) -> Unit) {
    val vm = graphViewModel(graph) { SettingsViewModel(it) }
    val p by vm.prefs.collectAsStateWithLifecycle()
    val prefs = p ?: Prefs()
    var confirm by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Settings") }
        item {
            FLCard {
                Text("Theme", style = MaterialTheme.typography.titleMedium)
                ThemeMode.values().forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.theme(m) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = prefs.theme == m, onClick = { vm.theme(m) })
                        Text(m.name.lowercase().replaceFirstChar { it.uppercase() })
                    }
                }
            }
        }
        item {
            FLCard {
                SwitchRow(
                    "Emergency override",
                    "Adds a button on the blocking screen that allows apps for 5 minutes. Every use is recorded on this device.",
                    prefs.emergencyOverride, { vm.setOverride(it) }
                )
                SwitchRow("Motivational message", null, prefs.motivation, { vm.motivation(it) })
            }
        }
        item { LinkRow("Shorts / Reels blocking (experimental)") { onNavigate(Routes.CONTENT) } }
        item { LinkRow("Permissions and setup") { onNavigate(Routes.PERMISSIONS) } }
        item { LinkRow("About and troubleshooting") { onNavigate(Routes.ABOUT) } }
        item {
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete all history") }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete all history?") },
            text = { Text("Sessions, block attempts and override records are removed from this device.") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.deleteHistory() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ContentSettingsScreen(graph: AppGraph, onBack: () -> Unit) {
    val vm = graphViewModel(graph) { SettingsViewModel(it) }
    val p by vm.prefs.collectAsStateWithLifecycle()
    val prefs = p ?: Prefs()
    val status by graph.contentBlocker.statusFlow.collectAsStateWithLifecycle()
    val log by graph.contentBlocker.logFlow.collectAsStateWithLifecycle()
    val fmt = remember { DateTimeFormatter.ofPattern("HH:mm:ss") }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Shorts / Reels", "Experimental · only during an active schedule") }
        item {
            FLCard {
                SwitchRow("Block YouTube Shorts", null, prefs.blockShorts, { vm.shorts(it) })
                SwitchRow("Block Instagram Reels", null, prefs.blockReels, { vm.reels(it) })
                SwitchRow(
                    "Fallback: block whole app when unsure",
                    "If only a partial match is found (reason ID_ONLY), block the entire app.",
                    prefs.fallbackWholeApp, { vm.fallback(it) }
                )
            }
        }
        item {
            FLCard {
                Text("Last detection", style = MaterialTheme.typography.titleMedium)
                Muted(
                    if (status.confidence == Confidence.NONE) "None yet."
                    else "${status.kind} · ${status.confidence} · ${status.reason}"
                )
                Muted("Not verified on real app versions. Turn on diagnostics, open Shorts/Reels during a schedule and check the log.")
            }
        }
        item {
            FLCard {
                SwitchRow(
                    "Diagnostic log",
                    "Keeps the last 30 detections in memory: reason code and counts only. No screen content.",
                    prefs.diagnostics, { vm.diagnostics(it) }
                )
                if (prefs.diagnostics) {
                    if (log.isEmpty()) Muted("No entries yet.")
                    log.take(15).forEach { e ->
                        Muted(
                            fmt.format(Instant.ofEpochMilli(e.at).atZone(ZoneId.systemDefault())) +
                                " ${e.kind?.name?.substringBefore('_') ?: "-"} ${e.confidence} ${e.reason} " +
                                "id=${e.idHits} label=${e.labelHits} sel=${e.selectedHits} n=${e.visited}"
                        )
                    }
                    TextButton(onClick = { graph.contentBlocker.clearLog() }) { Text("Clear log") }
                }
            }
        }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
}

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val perm = rememberPermState()
    val health by ServiceState.health.collectAsStateWithLifecycle()
    val fmt = remember { DateTimeFormatter.ofPattern("d MMM HH:mm:ss") }
    fun at(ms: Long) = fmt.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Service and permissions") }
        item {
            FLCard {
                Text("Accessibility service", style = MaterialTheme.typography.titleMedium)
                StatusLine(perm.accessibilityEnabled, "Enabled in Android settings")
                StatusLine(perm.serviceRunning, "Connected")
                if (health.connectedAt > 0) Muted("Connected at ${at(health.connectedAt)}")
                AgoText("Last event ", health.lastEventAt, "No events since it connected")
                if (health.lastBlockAt > 0) Muted("Last block screen: ${at(health.lastBlockAt)}")
                if (health.disconnects > 0) Muted("Disconnected ${health.disconnects}× (last ${at(health.lastDisconnectAt)})")
                health.lastFailure?.let { Muted("Last failure: $it (${at(health.lastFailureAt)})") }
                health.lastCrash?.let { Muted("Last app crash: $it (${at(health.lastCrashAt)})") }
                Button(onClick = { ctx.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Open Accessibility settings")
                }
                if (!perm.accessibilityEnabled) {
                    Muted("Greyed out? App info → ⋮ → Allow restricted settings.")
                    OutlinedButton(onClick = { ctx.openAppDetails() }, modifier = Modifier.fillMaxWidth()) { Text("Open App info") }
                } else if (!perm.serviceRunning) {
                    Muted("Android lists it as enabled but it isn't connected. Switch it off and on again; apps can't restart it.")
                }
            }
        }
        item {
            FLCard {
                Text("Battery", style = MaterialTheme.typography.titleMedium)
                StatusLine(perm.batteryExempt, "Not battery restricted")
                OutlinedButton(
                    onClick = { ctx.openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Open battery settings") }
            }
        }
        item { Muted("No other permissions are used: no notifications, exact alarms, overlay, usage access or internet.") }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("About", "FOCUS LOCK 2.0.0 · com.daksh.focuslock") }
        item {
            FLCard {
                Text("Limits", style = MaterialTheme.typography.titleMedium)
                Muted("Not tamper-proof: the service can be switched off, or the app force-stopped or uninstalled.")
                Muted("Phone battery managers can stop the service.")
                Muted("Shorts/Reels detection is experimental and unverified on real app versions.")
                Muted("All data stays on this device. No internet permission.")
            }
        }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
}
