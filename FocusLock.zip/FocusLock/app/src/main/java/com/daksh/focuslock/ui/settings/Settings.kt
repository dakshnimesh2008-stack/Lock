@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.focuslock.ui.settings

import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.daksh.focuslock.AppGraph
import com.daksh.focuslock.data.datastore.Prefs
import com.daksh.focuslock.data.datastore.ThemeMode
import com.daksh.focuslock.domain.content.Confidence
import com.daksh.focuslock.ui.components.FLCard
import com.daksh.focuslock.ui.components.Muted
import com.daksh.focuslock.ui.components.ScreenTitle
import com.daksh.focuslock.ui.components.StatusLine
import com.daksh.focuslock.ui.navigation.Routes
import com.daksh.focuslock.ui.util.graphViewModel
import com.daksh.focuslock.ui.util.openAppDetails
import com.daksh.focuslock.ui.util.openSettings
import com.daksh.focuslock.ui.util.rememberPermState
import kotlinx.coroutines.launch

class SettingsViewModel(private val g: AppGraph) : ViewModel() {
    val prefs = g.prefsState
    fun theme(m: ThemeMode) = viewModelScope.launch { g.prefs.setTheme(m) }
    fun shorts(v: Boolean) = viewModelScope.launch { g.prefs.setBlockShorts(v) }
    fun reels(v: Boolean) = viewModelScope.launch { g.prefs.setBlockReels(v) }
    fun fallback(v: Boolean) = viewModelScope.launch { g.prefs.setFallback(v) }
    fun setOverride(v: Boolean) = viewModelScope.launch { g.prefs.setEmergencyOverride(v) }
    fun motivation(v: Boolean) = viewModelScope.launch { g.prefs.setMotivation(v) }
    fun deleteHistory() = viewModelScope.launch { g.historyRepo.deleteAll() }
}

@Composable
private fun SwitchRow(title: String, detail: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (detail != null) Muted(detail)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun LinkRow(title: String, onClick: () -> Unit) {
    FLCard(onClick = onClick) { Text(title, style = MaterialTheme.typography.titleMedium) }
}

@Composable
fun SettingsScreen(graph: AppGraph, onNavigate: (String) -> Unit) {
    val vm = graphViewModel(graph) { SettingsViewModel(it) }
    val p by vm.prefs.collectAsStateWithLifecycle()
    val prefs = p ?: Prefs()
    var confirm by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Settings") }
        item {
            FLCard {
                Text("Theme", style = MaterialTheme.typography.titleMedium)
                ThemeMode.values().forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.theme(m) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = prefs.theme == m, onClick = { vm.theme(m) })
                        Text(m.name.lowercase().replaceFirstChar { it.uppercase() })
                    }
                }
            }
        }
        item {
            FLCard {
                SwitchRow(
                    "Emergency override",
                    "Adds a button on the blocking screen that allows apps for 5 minutes. Every use is recorded on this device.",
                    prefs.emergencyOverride, { vm.setOverride(it) }
                )
                SwitchRow("Motivational message", null, prefs.motivation, { vm.motivation(it) })
            }
        }
        item { LinkRow("Shorts / Reels blocking (experimental)") { onNavigate(Routes.CONTENT) } }
        item { LinkRow("Permissions and setup") { onNavigate(Routes.PERMISSIONS) } }
        item { LinkRow("About and troubleshooting") { onNavigate(Routes.ABOUT) } }
        item {
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete all history") }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete all history?") },
            text = { Text("Sessions, block attempts and override records are removed from this device.") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.deleteHistory() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ContentSettingsScreen(graph: AppGraph, onBack: () -> Unit) {
    val vm = graphViewModel(graph) { SettingsViewModel(it) }
    val p by vm.prefs.collectAsStateWithLifecycle()
    val prefs = p ?: Prefs()
    val status by graph.contentBlocker.statusFlow.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Shorts / Reels", "Experimental") }
        item {
            FLCard {
                Muted(
                    "Detection reads only view ids and short labels of the YouTube / Instagram screen while one of your " +
                        "schedules is active. Nothing is stored or sent. It can fail after app updates or in other languages. " +
                        "Whole-app blocking (apps selected in a schedule) always takes priority."
                )
            }
        }
        item {
            FLCard {
                SwitchRow("Block YouTube Shorts", "Needs a running schedule.", prefs.blockShorts, { vm.shorts(it) })
                SwitchRow("Block Instagram Reels", "Needs a running schedule.", prefs.blockReels, { vm.reels(it) })
                SwitchRow(
                    "Fallback: block whole app when unsure",
                    "If a Shorts/Reels screen is only partly recognized, block the entire app instead.",
                    prefs.fallbackWholeApp, { vm.fallback(it) }
                )
            }
        }
        item {
            FLCard {
                Text("Detection status", style = MaterialTheme.typography.titleMedium)
                Muted(
                    when (status.confidence) {
                        Confidence.NONE -> "Nothing detected yet. This is normal if you haven't opened Shorts/Reels during a schedule."
                        Confidence.UNCERTAIN -> "Last result: UNCERTAIN (${status.kind}). Partial match only, so no content block unless fallback is on."
                        Confidence.CONFIRMED -> "Last result: CONFIRMED (${status.kind})."
                    }
                )
                Muted("Guaranteed Shorts/Reels-only blocking is not claimed: it has not been verified on your device or app version.")
            }
        }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
}

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val perm = rememberPermState()
    var why by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Permissions and setup") }
        item {
            FLCard {
                Text("Accessibility service", style = MaterialTheme.typography.titleMedium)
                StatusLine(perm.accessibilityEnabled, "Enabled in Android settings")
                StatusLine(perm.serviceRunning, "Connected and running")
                Muted("Required for blocking. You enable it yourself; FOCUS LOCK can't turn it on.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { why = true }) { Text("Enable") }
                    OutlinedButton(onClick = { ctx.openAppDetails() }) { Text("App info") }
                }
            }
        }
        item {
            FLCard {
                Text("Battery optimization", style = MaterialTheme.typography.titleMedium)
                StatusLine(perm.batteryExempt, "App is not battery restricted")
                Muted("Some phones kill background apps. Setting FOCUS LOCK to unrestricted helps blocking stay reliable.")
                OutlinedButton(onClick = { ctx.openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }) {
                    Text("Open battery settings")
                }
            }
        }
        item {
            FLCard {
                Text("Not needed", style = MaterialTheme.typography.titleMedium)
                Muted("Notifications: not used. Exact alarms: not used (inexact alarms are enough). Usage access, overlay, device admin, VPN: never requested.")
            }
        }
        item {
            FLCard {
                Text("Installed from an APK file?", style = MaterialTheme.typography.titleMedium)
                Muted("On Android 13+ the Accessibility toggle may be greyed out. Open App info, tap the ⋮ menu and choose “Allow restricted settings”, then try again.")
            }
        }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
    if (why) {
        AlertDialog(
            onDismissRequest = { why = false },
            title = { Text("Why Accessibility?") },
            text = {
                Text(
                    "Android only reveals the foreground app through an Accessibility service. FOCUS LOCK uses it to " +
                        "see which app opened and show a focus screen for apps you chose. It does not read messages, " +
                        "passwords or typing, and nothing leaves your device. Next you'll see Android's Accessibility " +
                        "settings: find FOCUS LOCK and switch it on."
                )
            },
            confirmButton = {
                TextButton(onClick = { why = false; ctx.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) }) {
                    Text("Open settings")
                }
            },
            dismissButton = { TextButton(onClick = { why = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("About FOCUS LOCK", "Version 1.0.0 · com.daksh.focuslock") }
        item {
            FLCard {
                Text("Known limitations", style = MaterialTheme.typography.titleMedium)
                Muted("• Not tamper-proof: the accessibility service can be turned off, or the app force-stopped or uninstalled.")
                Muted("• Phone makers' battery managers can stop the service; set battery to unrestricted.")
                Muted("• Shorts/Reels detection is experimental and may break with app updates.")
                Muted("• Session durations are estimates based on when the device was observed running.")
                Muted("• Screen text is English only for now.")
            }
        }
        item {
            FLCard {
                Text("Troubleshooting", style = MaterialTheme.typography.titleMedium)
                Muted("1. Blocking does nothing: open Permissions and check both Accessibility lines are green.")
                Muted("2. Toggle greyed out: App info → ⋮ → Allow restricted settings.")
                Muted("3. Stopped after a while: set battery to unrestricted and lock the app in recents if your phone offers it.")
                Muted("4. After a reboot: open the app once; schedules are restored automatically.")
            }
        }
        item {
            FLCard {
                Text("Privacy", style = MaterialTheme.typography.titleMedium)
                Muted("All data stays on this device. No internet permission, no analytics, no accounts.")
            }
        }
        item { OutlinedButton(onClick = onBack) { Text("Back") } }
    }
}
