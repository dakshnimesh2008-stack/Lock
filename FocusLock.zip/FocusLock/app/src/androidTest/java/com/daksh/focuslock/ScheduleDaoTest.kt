package com.daksh.focuslock

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.daksh.focuslock.data.database.FocusDatabase
import com.daksh.focuslock.data.database.ScheduleEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Runs on a device/emulator: ./gradlew connectedDebugAndroidTest */
@RunWith(AndroidJUnit4::class)
class ScheduleDaoTest {
    private lateinit var db: FocusDatabase

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, FocusDatabase::class.java).allowMainThreadQueries().build()
    }

    @After fun tearDown() = db.close()

    @Test fun selectedAppsPersistWithSchedule() = runBlocking {
        val id = db.scheduleDao().upsert(
            ScheduleEntity(name = "a", startMinute = 1, endMinute = 2, daysMask = 1, enabled = true,
                packages = "com.a,com.b", description = "", strict = false, createdAt = 1, modifiedAt = 1)
        )
        assertEquals("com.a,com.b", db.scheduleDao().get(id)!!.packages)
        db.scheduleDao().delete(id)
        assertEquals(0, db.scheduleDao().all().size)
    }
}
