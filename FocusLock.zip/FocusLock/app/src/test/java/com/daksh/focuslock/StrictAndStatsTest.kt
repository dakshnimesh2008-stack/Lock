package com.daksh.focuslock

import com.daksh.focuslock.data.database.toDomain
import com.daksh.focuslock.data.database.toEntity
import com.daksh.focuslock.domain.model.BlockRecord
import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.model.SessionRecord
import com.daksh.focuslock.domain.scheduler.StrictPolicy
import com.daksh.focuslock.domain.usecase.StatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class StrictAndStatsTest {
    private val utc = ZoneId.of("UTC")
    private val all = DayOfWeek.values().toSet()
    private fun ms(s: String) = Instant.parse(s).toEpochMilli()

    private fun sched(strict: Boolean) =
        FocusSchedule(id = 1, name = "x", startMinute = 9 * 60, endMinute = 11 * 60, days = all, strict = strict)

    @Test fun strictLocksOnlyWhileActive() {
        assertTrue(StrictPolicy.isLocked(sched(true), Instant.parse("2024-01-01T10:00:00Z"), utc))
        assertFalse(StrictPolicy.isLocked(sched(true), Instant.parse("2024-01-01T12:00:00Z"), utc))
        assertFalse(StrictPolicy.isLocked(sched(false), Instant.parse("2024-01-01T10:00:00Z"), utc))
        assertTrue(StrictPolicy.canModify(sched(true), Instant.parse("2024-01-01T12:00:00Z"), utc))
    }

    @Test fun splitByDayAcrossMidnight() {
        val m = StatsCalculator.splitByDay(ms("2024-01-01T23:00:00Z"), ms("2024-01-02T01:30:00Z"), utc)
        assertEquals(3_600_000L, m[LocalDate.parse("2024-01-01")])
        assertEquals(5_400_000L, m[LocalDate.parse("2024-01-02")])
    }

    @Test fun interruptedSessionCountsOnlyObservedTime() {
        val s = SessionRecord(1, "x", ms("2024-01-01T09:00:00Z"), ms("2024-01-01T11:00:00Z"), ms("2024-01-01T09:30:00Z"))
        assertEquals(30 * 60_000L, s.focusedMs)
        assertFalse(s.completed)
        val stats = StatsCalculator.compute(listOf(s), emptyList(), ms("2024-01-01T20:00:00Z"), utc)
        assertEquals(30 * 60_000L, stats.todayFocusMs)
        assertEquals(0, stats.completedSessions)
    }

    @Test fun completedSessionAndBlockCounts() {
        val s = SessionRecord(1, "x", ms("2024-01-01T09:00:00Z"), ms("2024-01-01T11:00:00Z"), ms("2024-01-01T11:00:00Z"))
        val ev = listOf(
            BlockRecord(ms("2024-01-01T09:10:00Z"), "com.a", "APP", true),
            BlockRecord(ms("2024-01-01T09:20:00Z"), "com.a", "APP", false),
            BlockRecord(ms("2024-01-01T09:30:00Z"), "com.b", "OVERRIDE", true)
        )
        val st = StatsCalculator.compute(listOf(s), ev, ms("2024-01-01T20:00:00Z"), utc)
        assertEquals(1, st.completedSessions)
        assertEquals(2, st.attempts)      // override is not a block attempt
        assertEquals(1, st.confirmed)     // only one attempt actually showed the blocking screen
        assertEquals(listOf("com.a" to 2), st.topApps)
        assertEquals(7, st.week.size)
    }

    @Test fun entityRoundTripKeepsDaysAndPackages() {
        val s = FocusSchedule(
            id = 3, name = "n", startMinute = 60, endMinute = 120,
            days = setOf(DayOfWeek.MONDAY, DayOfWeek.SUNDAY), packages = setOf("b.b", "a.a"), strict = true
        )
        val back = s.toEntity().toDomain()
        assertEquals(s.days, back.days)
        assertEquals(s.packages, back.packages)
        assertTrue(back.strict)
    }
}
