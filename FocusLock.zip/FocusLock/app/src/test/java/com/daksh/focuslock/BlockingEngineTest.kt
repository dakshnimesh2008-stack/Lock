package com.daksh.focuslock

import com.daksh.focuslock.domain.blocking.BlockingEngine
import com.daksh.focuslock.domain.model.FocusSchedule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId

class BlockingEngineTest {
    private val utc = ZoneId.of("UTC")
    private val monday10 = Instant.parse("2024-01-01T10:00:00Z")
    private val all = DayOfWeek.values().toSet()

    private fun s(id: Long, start: Int, end: Int, vararg pkgs: String) =
        FocusSchedule(id = id, name = "s$id", startMinute = start, endMinute = end, days = all, packages = pkgs.toSet())

    @Test fun blocksSelectedPackageOnlyInsideWindow() {
        val e = BlockingEngine()
        e.updateSchedules(listOf(s(1, 9 * 60, 11 * 60, "com.x")))
        assertTrue(e.shouldBlockLaunch("com.x", monday10, utc))
        assertFalse(e.shouldBlockLaunch("com.y", monday10, utc))
        assertFalse(e.shouldBlockLaunch("com.x", Instant.parse("2024-01-01T11:00:00Z"), utc))
    }

    @Test fun neverBlocksOwnOrProtectedPackages() {
        val e = BlockingEngine("com.daksh.focuslock")
        e.updateSchedules(listOf(s(1, 0, 23 * 60, "com.daksh.focuslock", "com.android.settings", "com.android.phone")))
        assertFalse(e.shouldBlockLaunch("com.daksh.focuslock", monday10, utc))
        assertFalse(e.shouldBlockLaunch("com.android.settings", monday10, utc))
        assertFalse(e.shouldBlockLaunch("com.android.phone", monday10, utc))
    }

    @Test fun overlappingSchedulesBothActive() {
        val e = BlockingEngine()
        e.updateSchedules(listOf(s(1, 9 * 60, 11 * 60, "com.a"), s(2, 10 * 60, 12 * 60, "com.b")))
        assertEquals(2, e.getActiveRules(monday10, utc).size)
        assertTrue(e.isPackageBlocked("com.a", monday10, utc))
        assertTrue(e.isPackageBlocked("com.b", monday10, utc))
    }

    @Test fun refreshReflectsUpdatedSchedules() {
        val e = BlockingEngine()
        assertTrue(e.refreshActiveSchedules(monday10, utc).isEmpty())
        e.updateSchedules(listOf(s(1, 9 * 60, 11 * 60, "com.a")))
        assertEquals(1, e.refreshActiveSchedules(monday10, utc).size)
    }
}
