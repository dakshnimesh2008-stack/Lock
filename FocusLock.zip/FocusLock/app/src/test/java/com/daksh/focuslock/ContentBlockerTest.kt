package com.daksh.focuslock

import com.daksh.focuslock.domain.content.Confidence
import com.daksh.focuslock.domain.content.ContentBlocker
import com.daksh.focuslock.domain.content.ContentDecision
import com.daksh.focuslock.domain.content.ContentKind
import com.daksh.focuslock.domain.content.ContentPolicy
import com.daksh.focuslock.domain.content.Evidence
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** These use SYNTHETIC evidence. They do not prove behaviour on real YouTube/Instagram screens. */
class ContentBlockerTest {
    private val yt = "com.google.android.youtube"
    private val ig = "com.instagram.android"
    private val both = ContentPolicy(blockShorts = true, blockReels = true, fallbackWholeApp = false)

    @Test fun idAndLabelConfirm() {
        val r = ContentBlocker().detectSupportedContent(yt, Evidence(2, 1))
        assertEquals(Confidence.CONFIRMED, r.confidence)
        assertEquals("ID_AND_LABEL", r.reason)
    }

    @Test fun selectedTabConfirmsEvenWithoutIds() {
        val r = ContentBlocker().detectSupportedContent(yt, Evidence(idHits = 0, labelHits = 1, selectedHits = 1))
        assertEquals(Confidence.CONFIRMED, r.confidence)
        assertEquals("SELECTED_TAB", r.reason)
    }

    @Test fun idOnlyIsUncertain() {
        val r = ContentBlocker().detectSupportedContent(yt, Evidence(1, 0))
        assertEquals(Confidence.UNCERTAIN, r.confidence)
        assertEquals("ID_ONLY", r.reason)
    }

    @Test fun ordinaryVideoWithShortsLabelOnlyIsNotBlocked() {
        // Home tab selected, a "Shorts" shelf or hashtag is visible: label hit, nothing selected, no player id.
        val b = ContentBlocker()
        val r = b.detectSupportedContent(yt, Evidence(idHits = 0, labelHits = 3, selectedHits = 0, visited = 120))
        assertEquals(Confidence.NONE, r.confidence)
        assertEquals("LABEL_ONLY", r.reason)
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(r, both.copy(fallbackWholeApp = true), true))
    }

    @Test fun noSignalAndTruncated() {
        val b = ContentBlocker()
        assertEquals("NO_SIGNAL", b.detectSupportedContent(ig, Evidence(0, 0)).reason)
        assertEquals("NO_SIGNAL_TRUNCATED", b.detectSupportedContent(ig, Evidence(0, 0, truncated = true)).reason)
    }

    @Test fun unsupportedPackageIsIgnored() {
        val r = ContentBlocker().detectSupportedContent("com.other", Evidence(5, 5, 5))
        assertNull(r.kind)
        assertEquals(Confidence.NONE, r.confidence)
    }

    @Test fun policyBlocksOnlyConfirmedUnlessFallback() {
        val b = ContentBlocker()
        val confirmed = b.detectSupportedContent(ig, Evidence(1, 1))
        val uncertain = b.detectSupportedContent(ig, Evidence(1, 0))
        assertEquals(ContentKind.INSTAGRAM_REELS, confirmed.kind)
        assertEquals(ContentDecision.BLOCK_CONTENT, b.evaluateBlockingPolicy(confirmed, both, true))
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(uncertain, both, true))
        assertEquals(ContentDecision.BLOCK_APP_FALLBACK, b.evaluateBlockingPolicy(uncertain, both.copy(fallbackWholeApp = true), true))
    }

    @Test fun policyRespectsTogglesAndSchedule() {
        val b = ContentBlocker()
        val c = b.detectSupportedContent(yt, Evidence(1, 1))
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(c, both.copy(blockShorts = false), true))
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(c, both, false))
    }

    @Test fun diagnosticLogRecordsReasonsOnlyWhenEnabledAndCollapsesRepeats() {
        val b = ContentBlocker()
        b.detectSupportedContent(yt, Evidence(1, 1), recordLog = false)
        assertEquals(0, b.logFlow.value.size)
        b.detectSupportedContent(yt, Evidence(1, 1), recordLog = true)
        b.detectSupportedContent(yt, Evidence(1, 1), recordLog = true)
        b.detectSupportedContent(yt, Evidence(0, 1), recordLog = true)
        b.noteNoWindow(yt, recordLog = true)
        assertEquals(3, b.logFlow.value.size)
        assertEquals("NO_WINDOW", b.logFlow.value.first().reason)
    }

    @Test fun statusAndReset() {
        val b = ContentBlocker()
        b.detectSupportedContent(yt, Evidence(1, 1))
        assertEquals(Confidence.CONFIRMED, b.getDetectionStatus().confidence)
        b.resetDetectionState()
        assertEquals(Confidence.NONE, b.getDetectionStatus().confidence)
    }
}
