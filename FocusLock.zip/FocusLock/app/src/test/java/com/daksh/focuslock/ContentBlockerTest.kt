package com.daksh.focuslock

import com.daksh.focuslock.domain.content.Confidence
import com.daksh.focuslock.domain.content.ContentBlocker
import com.daksh.focuslock.domain.content.ContentDecision
import com.daksh.focuslock.domain.content.ContentKind
import com.daksh.focuslock.domain.content.ContentPolicy
import com.daksh.focuslock.domain.content.Evidence
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ContentBlockerTest {
    private val yt = "com.google.android.youtube"
    private val ig = "com.instagram.android"
    private val both = ContentPolicy(blockShorts = true, blockReels = true, fallbackWholeApp = false)

    @Test fun confirmedNeedsIdAndLabel() {
        val b = ContentBlocker()
        assertEquals(Confidence.CONFIRMED, b.detectSupportedContent(yt, Evidence(2, 1)).confidence)
        assertEquals(Confidence.UNCERTAIN, b.detectSupportedContent(yt, Evidence(1, 0)).confidence)
        assertEquals(Confidence.NONE, b.detectSupportedContent(yt, Evidence(0, 3)).confidence)
    }

    @Test fun unsupportedPackageIsIgnored() {
        val r = ContentBlocker().detectSupportedContent("com.other", Evidence(5, 5))
        assertNull(r.kind)
        assertEquals(Confidence.NONE, r.confidence)
    }

    @Test fun policyBlocksOnlyConfirmedUnlessFallback() {
        val b = ContentBlocker()
        val confirmed = b.detectSupportedContent(ig, Evidence(1, 1))
        val uncertain = b.detectSupportedContent(ig, Evidence(1, 0))
        assertEquals(ContentKind.INSTAGRAM_REELS, confirmed.kind)
        assertEquals(ContentDecision.BLOCK_CONTENT, b.evaluateBlockingPolicy(confirmed, both, true))
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(uncertain, both, true))
        assertEquals(ContentDecision.BLOCK_APP_FALLBACK, b.evaluateBlockingPolicy(uncertain, both.copy(fallbackWholeApp = true), true))
    }

    @Test fun policyRespectsTogglesAndSchedule() {
        val b = ContentBlocker()
        val c = b.detectSupportedContent(yt, Evidence(1, 1))
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(c, both.copy(blockShorts = false), true))
        assertEquals(ContentDecision.ALLOW, b.evaluateBlockingPolicy(c, both, false))
    }

    @Test fun statusAndReset() {
        val b = ContentBlocker()
        b.detectSupportedContent(yt, Evidence(1, 1))
        assertEquals(Confidence.CONFIRMED, b.getDetectionStatus().confidence)
        b.resetDetectionState()
        assertEquals(Confidence.NONE, b.getDetectionStatus().confidence)
    }
}
