package com.daksh.focuslock

import com.daksh.focuslock.accessibility.ServiceHealth
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ServiceHealthTest {
    @Test fun connectDisconnectTransitions() {
        val h = ServiceHealth().onConnected(100)
        assertTrue(h.connected)
        assertEquals(100L, h.connectedAt)
        val d = h.onDisconnected(500)
        assertFalse(d.connected)
        assertEquals(1, d.disconnects)
        assertEquals(500L, d.lastDisconnectAt)
        assertEquals(2, d.onConnected(600).onDisconnected(700).disconnects)
    }

    @Test fun eventTimestampIsThrottled() {
        val h = ServiceHealth().withEvent(10_000)
        assertEquals(10_000L, h.lastEventAt)
        assertEquals(10_000L, h.withEvent(12_000).lastEventAt)   // within 5s: unchanged (no UI churn)
        assertEquals(16_000L, h.withEvent(16_000).lastEventAt)
    }

    @Test fun failureAndCrashAreRecordedWithoutChangingConnection() {
        val h = ServiceHealth().onConnected(1).withFailure("event: NullPointerException @ X.kt:1", 5).withCrash("Boom @ Y.kt:2", 9)
        assertTrue(h.connected)
        assertEquals(5L, h.lastFailureAt)
        assertEquals(9L, h.lastCrashAt)
        assertNull(ServiceHealth().lastFailure)
    }
}
