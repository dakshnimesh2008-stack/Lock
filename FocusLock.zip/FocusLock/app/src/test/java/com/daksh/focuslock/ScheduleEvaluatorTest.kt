package com.daksh.focuslock

import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.Duration
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

class ScheduleEvaluatorTest {
    private val utc = ZoneId.of("UTC")
    private val ny = ZoneId.of("America/New_York")

    private fun at(s: String, zone: ZoneId = utc): Instant = LocalDateTime.parse(s).atZone(zone).toInstant()

    private val weekdays = setOf(
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY
    )

    private fun sched(start: Int, end: Int, days: Set<DayOfWeek> = weekdays, enabled: Boolean = true) =
        FocusSchedule(id = 1, name = "t", startMinute = start, endMinute = end, days = days, enabled = enabled)

    // 2024-01-01 is a Monday.
    @Test fun startIsInclusiveEndIsExclusive() {
        val s = sched(9 * 60, 17 * 60)
        assertFalse(ScheduleEvaluator.isActive(s, at("2024-01-01T08:59:59"), utc))
        assertTrue(ScheduleEvaluator.isActive(s, at("2024-01-01T09:00:00"), utc))
        assertTrue(ScheduleEvaluator.isActive(s, at("2024-01-01T16:59:59"), utc))
        assertFalse(ScheduleEvaluator.isActive(s, at("2024-01-01T17:00:00"), utc))
    }

    @Test fun weekdayMatching() {
        val s = sched(9 * 60, 17 * 60)
        assertFalse(ScheduleEvaluator.isActive(s, at("2024-01-06T10:00:00"), utc)) // Saturday
        assertTrue(ScheduleEvaluator.isActive(s, at("2024-01-05T10:00:00"), utc)) // Friday
    }

    @Test fun overnightBelongsToStartDay() {
        val s = sched(22 * 60, 6 * 60, setOf(DayOfWeek.FRIDAY))
        assertFalse(ScheduleEvaluator.isActive(s, at("2024-01-05T21:59:59"), utc))
        assertTrue(ScheduleEvaluator.isActive(s, at("2024-01-05T22:00:00"), utc))
        assertTrue(ScheduleEvaluator.isActive(s, at("2024-01-06T02:00:00"), utc)) // Saturday morning, window began Friday
        assertFalse(ScheduleEvaluator.isActive(s, at("2024-01-06T06:00:00"), utc))
        assertFalse(ScheduleEvaluator.isActive(s, at("2024-01-06T23:00:00"), utc)) // Saturday not selected
    }

    @Test fun disabledOrInvalidNeverActive() {
        assertFalse(ScheduleEvaluator.isActive(sched(9 * 60, 17 * 60, enabled = false), at("2024-01-01T10:00:00"), utc))
        assertFalse(ScheduleEvaluator.isActive(sched(600, 600), at("2024-01-01T10:00:00"), utc))
        assertFalse(ScheduleEvaluator.isActive(sched(9 * 60, 17 * 60, emptySet()), at("2024-01-01T10:00:00"), utc))
    }

    @Test fun timeZoneChangesResult() {
        val s = sched(9 * 60, 10 * 60)
        val i = Instant.parse("2024-01-01T14:30:00Z") // 09:30 in New York
        assertFalse(ScheduleEvaluator.isActive(s, i, utc))
        assertTrue(ScheduleEvaluator.isActive(s, i, ny))
    }

    @Test fun dstSpringForwardWindowIsTwoHours() {
        // 2024-03-10: clocks jump 02:00 -> 03:00 in New York. 01:00-04:00 is only 2 real hours.
        val s = sched(60, 4 * 60, setOf(DayOfWeek.SUNDAY))
        val w = ScheduleEvaluator.activeWindow(s, at("2024-03-10T01:30:00", ny), ny)
        assertNotNull(w)
        assertEquals(Duration.ofHours(2), Duration.between(w!!.start, w.end))
    }

    @Test fun nextBoundaryAndNextStart() {
        val s = sched(9 * 60, 17 * 60)
        assertEquals(at("2024-01-01T09:00:00"), ScheduleEvaluator.nextBoundary(s, at("2024-01-01T08:00:00"), utc))
        assertEquals(at("2024-01-01T17:00:00"), ScheduleEvaluator.nextBoundary(s, at("2024-01-01T09:00:00"), utc))
        assertEquals(at("2024-01-08T09:00:00"), ScheduleEvaluator.nextStart(sched(9 * 60, 17 * 60, setOf(DayOfWeek.MONDAY)), at("2024-01-01T10:00:00"), utc))
        assertNull(ScheduleEvaluator.nextBoundary(sched(9 * 60, 17 * 60, enabled = false), at("2024-01-01T08:00:00"), utc))
    }
}
