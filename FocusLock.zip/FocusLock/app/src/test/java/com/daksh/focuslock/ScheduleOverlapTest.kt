package com.daksh.focuslock

import com.daksh.focuslock.domain.model.FocusSchedule
import com.daksh.focuslock.domain.scheduler.ScheduleEvaluator
import com.daksh.focuslock.domain.scheduler.ScheduleOverlap
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId

class ScheduleOverlapTest {
    private val utc = ZoneId.of("UTC")
    private val from = Instant.parse("2024-01-01T00:00:00Z")
    private val all = DayOfWeek.values().toSet()

    private fun s(id: Long, start: Int, end: Int, days: Set<DayOfWeek> = all) =
        FocusSchedule(id = id, name = "s$id", startMinute = start, endMinute = end, days = days)

    @Test fun overlappingAndTouchingIntervals() {
        assertTrue(ScheduleOverlap.overlaps(s(1, 9 * 60, 11 * 60), s(2, 10 * 60, 12 * 60), from, utc))
        // End-exclusive: 09:00-10:00 and 10:00-11:00 do not overlap.
        assertFalse(ScheduleOverlap.overlaps(s(1, 9 * 60, 10 * 60), s(2, 10 * 60, 11 * 60), from, utc))
    }

    @Test fun overnightOverlapsNextMorning() {
        val night = s(1, 22 * 60, 6 * 60, setOf(DayOfWeek.FRIDAY))
        val sat = s(2, 5 * 60, 7 * 60, setOf(DayOfWeek.SATURDAY))
        val fri = s(3, 5 * 60, 7 * 60, setOf(DayOfWeek.FRIDAY))
        assertTrue(ScheduleOverlap.overlaps(night, sat, from, utc))
        assertFalse(ScheduleOverlap.overlaps(night, fri, from, utc))
    }

    @Test fun overlappingExcludesSelf() {
        val a = s(1, 9 * 60, 11 * 60)
        val list = listOf(a, s(2, 10 * 60, 12 * 60), s(3, 13 * 60, 14 * 60))
        assertEquals(listOf(2L), ScheduleOverlap.overlapping(a, list, from, utc).map { it.id })
    }

    @Test fun durationMinutesWrapsMidnight() {
        assertEquals(60, ScheduleEvaluator.durationMinutes(s(1, 9 * 60, 10 * 60)))
        assertEquals(8 * 60, ScheduleEvaluator.durationMinutes(s(1, 22 * 60, 6 * 60)))
    }
}
